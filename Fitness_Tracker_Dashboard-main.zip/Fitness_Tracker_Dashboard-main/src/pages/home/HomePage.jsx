import React, { useState, useEffect, useRef } from "react";
import { motion, useScroll, useTransform, AnimatePresence, useInView } from "framer-motion";
import { FiArrowRight, FiPlay, FiUser, FiActivity, FiBarChart2, FiClipboard, FiArrowDown } from "react-icons/fi";
import axios from 'axios';
import { useNavigate } from "react-router-dom";


const handleLogout = async () => {
  try {
    const token = localStorage.getItem('authToken');
    await axios.post('http://localhost:5000/api/users/logout', {}, {
      headers: { Authorization: `Bearer ${token}` }
    });
    localStorage.clear();
    window.location.href = '/';
  } catch (error) {
    console.error('Logout failed:', error);
    alert('Failed to logout. Please try again.');
  }
};



// Reusable component for scroll-triggered animations
const RevealSection = ({ children, direction = "up", className }) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: false, amount: 0.3 });
  
  const variants = {
    hidden: {
      y: direction === "up" ? 100 : direction === "down" ? -100 : 0,
      x: direction === "left" ? 100 : direction === "right" ? -100 : 0,
      opacity: 0,
      scale: direction === "scale" ? 0.8 : 1
    },
    visible: {
      y: 0,
      x: 0,
      opacity: 1,
      scale: 1,
      transition: {
        duration: 0.9,
        ease: [0.22, 1, 0.36, 1]
      }
    }
  };

  return (
    <motion.div
      ref={ref}
      initial="hidden"
      animate={isInView ? "visible" : "hidden"}
      variants={variants}
      className={className}
    >
      {children}
    </motion.div>
  );
};

const Homepage = () => {
  const containerRef = useRef(null);
  const { scrollYProgress } = useScroll({ target: containerRef, offset: ["start start", "end start"] });
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [cursorVariant, setCursorVariant] = useState("default");
  const y1 = useTransform(scrollYProgress, [0, 1], [0, 100]);
  const y2 = useTransform(scrollYProgress, [0, 1], [0, -100]);
  const heroOpacity = useTransform(scrollYProgress, [0, 0.3], [1, 0]);
  const heroScale = useTransform(scrollYProgress, [0, 0.3], [1, 0.95]);
  const [isHovering, setIsHovering] = useState(false);
  const [activeFeature, setActiveFeature] = useState(0);
  const [showVideo, setShowVideo] = useState(false);
  const [clouds, setClouds] = useState([
    { id: 1, x: -5, speed: 0.3, size: 80, opacity: 0.8 },
    { id: 2, x: 30, speed: 0.2, size: 120, opacity: 0.6 },
    { id: 3, x: 70, speed: 0.4, size: 90, opacity: 0.7 },
  ]);
  
  // Reference for scroll indicator
  const scrollIndicatorRef = useRef(null);
  const navigate = useNavigate();


  useEffect(() => {
    const animateClouds = () => {
      setClouds(prev => prev.map(cloud => ({ ...cloud, x: (cloud.x + cloud.speed) % 120 - 20 })));
      requestAnimationFrame(animateClouds);
    };
    const frameId = requestAnimationFrame(animateClouds);
    return () => cancelAnimationFrame(frameId);
  }, []);

  const features = [
    { title: "Analyze Progress", description: "Visualize your fitness journey with interactive charts and graphs." },
    { title: "Nutrition Tracking", description: "Monitor your calories and macros to optimize your diet." },
    { title: "Goal Setting", description: "Set targets and get notified when you reach milestones." }
  ];

  const testimonials = [
    {
      id: 1,
      name: "Sarah Johnson",
      role: "Marathon Runner",
      image: "/images/testimonial-1.jpg",
      text: "FitTrack has transformed how I prepare for marathons. The detailed analytics helped me optimize my training schedule!"
    },
    {
      id: 2,
      name: "Michael Chen",
      role: "Personal Trainer",
      image: "/images/testimonial-2.jpg",
      text: "I recommend FitTrack to all my clients. The nutrition tracking paired with workout data gives a complete fitness picture."
    },
    {
      id: 3,
      name: "Jessica Smith",
      role: "Yoga Instructor",
      image: "/images/testimonial-3.jpg",
      text: "The progress tracking features in FitTrack motivate my students to maintain consistency in their yoga practice."
    }
  ];

  const pricingPlans = [
    {
      title: "Basic",
      price: "Free",
      features: ["Workout tracking", "Basic analytics", "Nutrition logging", "Goal setting"],
      recommended: false,
      color: "bg-gray-100"
    },
    {
      title: "Premium",
      price: "$9.99",
      period: "/month",
      features: ["Everything in Basic", "Advanced analytics", "Custom workout plans", "Priority support", "No ads"],
      recommended: true,
      color: "bg-purple-100"
    },
    {
      title: "Pro Athlete",
      price: "$19.99",
      period: "/month",
      features: ["Everything in Premium", "Personal coach", "Video analysis", "Exclusive content", "API access"],
      recommended: false,
      color: "bg-orange-100"
    }
  ];

  const cursorVariants = {
    default: { x: mousePosition.x - 16, y: mousePosition.y - 16, height: 32, width: 32 },
    text: { x: mousePosition.x - 16, y: mousePosition.y - 16, height: 64, width: 64, mixBlendMode: "difference" },
    button: { x: mousePosition.x - 32, y: mousePosition.y - 32, height: 64, width: 64, backgroundColor: "rgba(147, 51, 234, 0.2)", mixBlendMode: "normal" }
  };

  useEffect(() => {
    const interval = setInterval(() => setActiveFeature(prev => (prev + 1) % features.length), 4000);
    return () => clearInterval(interval);
  }, [features.length]);

  
  return (
    <div className="relative overflow-hidden" ref={containerRef}>
      <motion.div className="fixed top-0 left-0 rounded-full pointer-events-none z-50 border-2 border-purple-500" variants={cursorVariants} animate={cursorVariant} transition={{ type: "spring", damping: 25, stiffness: 700 }} />

      {clouds.map(cloud => (
        <motion.div key={cloud.id} className="absolute pointer-events-none" style={{ top: `${20 + (cloud.id * 10)}%`, left: `${cloud.x}%`, width: `${cloud.size}px`, height: `${cloud.size * 0.6}px`, backgroundColor: "white", borderRadius: "50%", filter: "blur(20px)", opacity: cloud.opacity, zIndex: 1 }} />
      ))}
      
      {/* Hero section with scale/fade out effect on scroll */}
      <motion.div 
        className="grid grid-cols-1 md:grid-cols-2 items-center px-0 md:px-20 py-0 gap-0 min-h-[100vh] relative z-10"
        style={{ opacity: heroOpacity, scale: heroScale }}
      >
        <motion.div 
          className="space-y-6 bg-amber-50 flex flex-col justify-center items-center text-center p-10 relative overflow-hidden"
          style={{ y: y1 }}
        >
          {/* Animated background elements */}
          <motion.div 
            className="absolute w-40 h-40 rounded-full bg-purple-200 opacity-40 top-10 left-10"
            animate={{ 
              scale: [1, 1.2, 1], 
              rotate: [0, 45, 0],
              x: [0, 20, 0],
              y: [0, -20, 0]
            }}
            transition={{ 
              duration: 15, 
              repeat: Infinity,
              ease: "easeInOut" 
            }}
          />
          
          <motion.div 
            className="absolute w-60 h-60 rounded-full bg-orange-200 opacity-30 bottom-0 right-0"
            animate={{ 
              scale: [1, 1.3, 1], 
              rotate: [0, -30, 0],
              x: [0, -30, 0],
              y: [0, 30, 0]
            }}
            transition={{ 
              duration: 18, 
              repeat: Infinity,
              ease: "easeInOut",
              delay: 1
            }}
          />
          
          <motion.p 
            className="text-sm text-orange-500 font-semibold relative z-10"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            onMouseEnter={() => setCursorVariant("text")}
            onMouseLeave={() => setCursorVariant("default")}
          >
            NOW TRACKING YOUR FITNESS IS OUR DUTY
          </motion.p>
          
          <motion.h1 
            className="text-4xl md:text-5xl font-bold leading-snug relative z-10"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            onMouseEnter={() => setCursorVariant("text")}
            onMouseLeave={() => setCursorVariant("default")}
          >
            Stay{" "}
            <motion.span 
              className="text-purple-700 inline-block"
              animate={{ 
                y: [0, -10, 0],
                scale: [1, 1.1, 1]
              }}
              transition={{ 
                duration: 2, 
                repeat: Infinity,
                repeatType: "loop"
              }}
            >
              Strong
            </motion.span>
            <br />
            Eat Healthy &<br />
            <motion.span 
              className="text-purple-700 inline-block"
              animate={{ 
                y: [0, -10, 0],
                scale: [1, 1.1, 1]
              }}
              transition={{ 
                duration: 2, 
                repeat: Infinity,
                repeatType: "loop",
                delay: 0.5
              }}
            >
              Worry Less
            </motion.span>
          </motion.h1>
          
          <motion.p 
            className="text-gray-600 text-sm max-w-md relative z-10"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            onMouseEnter={() => setCursorVariant("text")}
            onMouseLeave={() => setCursorVariant("default")}
          >
            FitTrack is a comprehensive fitness tracking platform that allows users to collect, analyze, and visualize their fitness data for optimal results.
          </motion.p>
          
          <motion.div 
            className="flex space-x-4 relative z-10"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
          >
           <motion.button 
  className="bg-purple-600 text-white px-6 py-2 rounded-lg overflow-hidden relative group flex items-center space-x-2"
  whileHover={{ scale: 1.05 }}
  whileTap={{ scale: 0.95 }}
  onClick={() => {
    document.getElementById("next-section")?.scrollIntoView({ behavior: "smooth" });
  }}
  onMouseEnter={() => setCursorVariant("button")}
  onMouseLeave={() => setCursorVariant("default")}
>
  <span className="relative z-10">Get Started</span>
  <motion.div 
    className="absolute top-0 left-0 right-0 bottom-0 bg-purple-800"
    initial={{ x: "-100%" }}
    whileHover={{ x: 0 }}
    transition={{ type: "spring" }}
  />
  <motion.div
    className="ml-1 relative z-10"
    animate={{ x: [0, 5, 0] }}
    transition={{ duration: 1.5, repeat: Infinity }}
  >
    <FiArrowRight />
  </motion.div>
</motion.button>

            
            
          </motion.div>
          
          {/* Features carousel */}
          <motion.div 
            className="mt-0 bg-white p-6 rounded-xl shadow-lg w-full max-w-md relative"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1 }}
          >
            <div className="flex justify-between items-center mb-0">
              <h3 className="font-bold text-lg">Key Features</h3>
              <div className="flex space-x-1">
                {features.map((_, index) => (
                  <motion.div 
                    key={index}
                    className="w-2 h-2 rounded-full"
                    animate={{
                      backgroundColor: activeFeature === index ? "#9333EA" : "#E5E7EB"
                    }}
                    onClick={() => setActiveFeature(index)}
                    style={{ cursor: "pointer" }}
                  />
                ))}
              </div>
            </div>
            
            <AnimatePresence mode="wait">
              <motion.div 
                key={activeFeature}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
                className="min-h-24"
              >
                <h4 className="font-semibold text-purple-700 mb-2">{features[activeFeature].title}</h4>
                <p className="text-sm text-gray-600">{features[activeFeature].description}</p>
              </motion.div>
            </AnimatePresence>
          </motion.div>
        </motion.div>

        <motion.div 
          className="relative h-full flex items-center justify-center min-h-[60vh]"
          style={{ y: y2 }}
        >
          <motion.div 
            className="absolute w-96 h-96 bg-purple-100 rounded-full top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"
            animate={{ 
              scale: [1, 1.1, 1], 
            }}
            transition={{ 
              duration: 8, 
              repeat: Infinity,
              ease: "easeInOut" 
            }}
          />
          
          <motion.div 
            className="rounded-2xl overflow-hidden shadow-xl relative z-10 w-10/12 max-w-xl"
            whileHover={{ 
              scale: 1.03,
              boxShadow: "0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)"
            }}
            initial={{ x: 100, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ type: "spring", damping: 20, stiffness: 100, delay: 0.5 }}
          >
            <img
              src="/images/fitness-image.png"
              alt="Fitness woman"
              className="w-full h-full object-cover"
            />
            
            {/* Floating stats badges */}
            <motion.div
              className="absolute -top-4 -left-4 bg-white rounded-lg shadow-lg p-3 flex items-center space-x-2"
              animate={{ 
                y: [0, -10, 0],
              }}
              transition={{ 
                duration: 4, 
                repeat: Infinity,
                ease: "easeInOut" 
              }}
            >
              <FiActivity className="text-red-500" />
              <div>
                <div className="text-xs text-gray-500">Daily Steps</div>
                <div className="font-bold">12,458</div>
              </div>
            </motion.div>
            
            <motion.div
              className="absolute bottom-10 -right-4 bg-white rounded-lg shadow-lg p-3 flex items-center space-x-2"
              animate={{ 
                y: [0, 10, 0],
              }}
              transition={{ 
                duration: 5, 
                repeat: Infinity,
                ease: "easeInOut",
                delay: 1
              }}
            >
              <FiBarChart2 className="text-purple-500" />
              <div>
                <div className="text-xs text-gray-500">Weekly Progress</div>
                <div className="font-bold">+24%</div>
              </div>
            </motion.div>
          </motion.div>
          
          {/* 3D rotating fitness icons */}
          <div className="absolute w-full h-full pointer-events-none">
            {[
              { Icon: FiActivity, top: "20%", left: "10%", delay: 0, color: "#F97316" },
              { Icon: FiBarChart2, top: "70%", left: "15%", delay: 0.5, color: "#9333EA" },
              { Icon: FiClipboard, top: "30%", left: "85%", delay: 1, color: "#2563EB" },
              { Icon: FiUser, top: "75%", left: "80%", delay: 1.5, color: "#10B981" }
            ].map((item, index) => (
              <motion.div
                key={index}
                className="absolute p-3 bg-white rounded-full shadow-md text-lg"
                style={{
                  top: item.top,
                  left: item.left,
                  color: item.color
                }}
                animate={{ 
                  rotate: [0, 360],
                  y: [0, -15, 0]
                }}
                transition={{ 
                  rotate: { duration: 10, repeat: Infinity, ease: "linear" },
                  y: { duration: 3, repeat: Infinity, ease: "easeInOut", delay: item.delay }
                }}
              >
                <item.Icon />
              </motion.div>
            ))}
          </div>
        </motion.div>
        
        {/* Scroll indicator */}
        <motion.div 
          className="absolute bottom-10 left-1/2 transform -translate-x-1/2 flex flex-col items-center"
          ref={scrollIndicatorRef}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2, duration: 1 }}
        >
          <motion.p 
            className="text-sm text-gray-500 mb-2"
            animate={{ y: [0, 5, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            Scroll to explore
          </motion.p>
          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          >
            <FiArrowDown className="text-purple-600" />
          </motion.div>
        </motion.div>
      </motion.div>
      
      {/* Features Section - Slides in from sides when scrolled to */}
      <div className="bg-white py-24 px-8 md:px-16">
        <div className="max-w-6xl mx-auto">
          <RevealSection direction="up" className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Track Everything, <span className="text-purple-600">Miss Nothing</span></h2>
            <p className="text-gray-600 max-w-2xl mx-auto">Our comprehensive tracking tools help you monitor every aspect of your fitness journey, from workouts to nutrition to sleep.</p>
          </RevealSection>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            {features.map((feature, index) => (
              <RevealSection 
                key={index} 
                direction={index % 2 === 0 ? "left" : "right"}
                className="bg-gray-50 rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow duration-300"
              >
                <div className={`w-12 h-12 rounded-full flex items-center justify-center mb-4 ${index % 3 === 0 ? 'bg-purple-100' : index % 3 === 1 ? 'bg-orange-100' : 'bg-blue-100'}`}>
                  {index % 4 === 0 ? <FiActivity className="text-purple-600" /> : 
                   index % 4 === 1 ? <FiBarChart2 className="text-orange-500" /> : 
                   index % 4 === 2 ? <FiClipboard className="text-blue-500" /> : 
                   <FiUser className="text-green-500" />}
                </div>
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
                <motion.div 
                  className="mt-4 text-purple-600 font-medium flex items-center cursor-pointer"
                  whileHover={{ x: 5 }}
                >
                  Learn more <FiArrowRight className="ml-2" />
                </motion.div>
              </RevealSection>
            ))}
          </div>
        </div>
      </div>
      
      {/* Testimonials Section - Slides in from bottom */}
      <div className="bg-gray-50 py-24 px-8 md:px-16">
        <div className="max-w-6xl mx-auto">
          <RevealSection direction="up" className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">What Our <span className="text-purple-600">Users Say</span></h2>
            <p className="text-gray-600 max-w-2xl mx-auto">Join thousands of satisfied users who have transformed their fitness journey with FitTrack.</p>
          </RevealSection>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <RevealSection 
                key={testimonial.id}
                direction="up"
                className="bg-white rounded-xl p-6 shadow-lg relative"
              >
                <div className="absolute -top-6 left-6 w-12 h-12 rounded-full overflow-hidden border-2 border-white shadow-md">
                  <div className="w-full h-full bg-purple-200 flex items-center justify-center">
                    <span className="text-purple-600 font-bold">{testimonial.name.charAt(0)}</span>
                  </div>
                </div>
                <div className="pt-6">
                  <p className="text-gray-600 italic mb-4">"{testimonial.text}"</p>
                  <div>
                    <h4 className="font-semibold">{testimonial.name}</h4>
                    <p className="text-sm text-gray-500">{testimonial.role}</p>
                  </div>
                </div>
              </RevealSection>
            ))}
          </div>
        </div>
      </div>
      
      {/* Pricing Section - Slides from right */}
      <div className="bg-white py-24 px-8 md:px-16">
        <div className="max-w-6xl mx-auto">
          <RevealSection direction="up" className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Simple, <span className="text-purple-600">Transparent Pricing</span></h2>
            <p className="text-gray-600 max-w-2xl mx-auto">Choose the plan that fits your fitness goals and budget.</p>
          </RevealSection>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {pricingPlans.map((plan, index) => (
              <RevealSection
                key={index}
                direction={index === 0 ? "left" : index === 1 ? "up" : "right"}
                className={`rounded-xl p-6 shadow-lg ${plan.recommended ? 'relative border-2 border-purple-400' : ''} ${plan.color}`}
              >
                {plan.recommended && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-purple-600 text-white px-4 py-1 rounded-full text-sm font-medium">
                    Most Popular
                  </div>
                )}
                <h3 className="text-xl font-bold mb-2">{plan.title}</h3>
                <div className="mb-4">
                  <span className="text-3xl font-bold">{plan.price}</span>
                  {plan.period && <span className="text-gray-600">{plan.period}</span>}
                </div>
                <ul className="mb-6 space-y-2">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start">
                      <svg className="w-5 h-5 text-green-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>
                <motion.button
                  className={`w-full py-2 rounded-lg font-medium ${plan.recommended ? 'bg-purple-600 text-white' : 'bg-gray-200 text-gray-800'}`}
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={() => {
                    document.getElementById("next-section")?.scrollIntoView({ behavior: "smooth" });
                  }}
                  
                >
                  Get Started
                </motion.button>
              </RevealSection>
            ))}
          </div>
        </div>
      </div>
      
     
      
      {/* App Features Section - Staggered Animation */}
      <div className="bg-gray-50 py-24 px-8 md:px-16">
        <div className="max-w-6xl mx-auto">
          <RevealSection direction="up" className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Powerful <span className="text-purple-600">App Features</span></h2>
            <p className="text-gray-600 max-w-2xl mx-auto">Everything you need to achieve your fitness goals, right at your fingertips.</p>
          </RevealSection>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[
              {
                title: "Smart Workout Plans",
                description: "AI-generated workout plans tailored to your goals, equipment, and fitness level.",
                icon: FiActivity,
                color: "bg-purple-100",
                iconColor: "text-purple-600"
              },
              {
                title: "Detailed Analytics",
                description: "Visualize your progress with comprehensive charts and performance metrics.",
                icon: FiBarChart2,
                color: "bg-blue-100",
                iconColor: "text-blue-600"
              },
              {
                title: "Nutrition Tracking",
                description: "Log meals and track macros with our extensive food database and barcode scanner.",
                icon: FiClipboard,
                color: "bg-orange-100",
                iconColor: "text-orange-600"
              },
              {
                title: "Community Support",
                description: "Connect with like-minded fitness enthusiasts to stay motivated and share tips.",
                icon: FiUser,
                color: "bg-green-100",
                iconColor: "text-green-600"
              }
            ].map((feature, index) => (
              <RevealSection 
                key={index}
                direction={index % 2 === 0 ? "left" : "right"}
                className="flex items-start p-6 bg-white rounded-xl shadow-md"
              >
                <div className={`flex-shrink-0 w-12 h-12 ${feature.color} rounded-lg flex items-center justify-center mr-4`}>
                  <feature.icon className={`text-xl ${feature.iconColor}`} />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </div>
              </RevealSection>
            ))}
          </div>
        </div>
      </div>

      <section id="next-section" className="relative z-10">

      <RevealSection direction="up" >
        <div className="bg-purple-600 text-white py-16 px-8 relative overflow-hidden">
          <div className="max-w-4xl mx-auto text-center relative z-10">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Transform Your Fitness Journey?</h2>
            <p className="mb-8 text-purple-100">Join thousands of users who have already improved their fitness with FitTrack.</p>
            <motion.button
              className="bg-white text-purple-600 font-medium px-8 py-3 rounded-lg"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Start Your Free Trial
            </motion.button>
          </div>
          <motion.div 
            className="absolute top-0 left-0 w-full h-full opacity-10"
            animate={{ 
              backgroundPosition: ['0% 0%', '100% 100%']
            }}
            transition={{ 
              duration: 20,
              repeat: Infinity,
              repeatType: "mirror"
            }}
            style={{
              backgroundImage: 'url("data:image/svg+xml,%3Csvg width=\'100\' height=\'100\' viewBox=\'0 0 100 100\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cpath d=\'M11 18c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm48 25c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm-43-7c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm63 31c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3zm-63-60c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM34 90c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm56-76c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM12 86c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm28-65c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm23-11c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-6 60c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm29 22c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zM32 63c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm57-13c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-9-21c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM60 91c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM35 41c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM12 60c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2z\' fill=\'%23ffffff\' fill-opacity=\'1\' fill-rule=\'evenodd\'/%3E%3C/svg%3E")'
            }}
          />
        </div>
      </RevealSection>
      </section>
      
    
      
      {/* FAQ Section with accordion effect */}
      <div className="bg-gray-50 py-24 px-8 md:px-16">
        <div className="max-w-4xl mx-auto">
          <RevealSection direction="up" className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Frequently Asked <span className="text-purple-600">Questions</span></h2>
            <p className="text-gray-600 max-w-2xl mx-auto">Find answers to common questions about FitTrack.</p>
          </RevealSection>
          
          <div className="space-y-6">
            {[
              {
                question: "How does FitTrack sync with other fitness devices?",
                answer: "FitTrack seamlessly integrates with popular fitness wearables like Fitbit, Apple Watch, and Garmin. Simply connect your device through our app settings, and your data will automatically sync after each workout."
              },
              {
                question: "Is there a free trial available?",
                answer: "Yes! We offer a 14-day free trial of our Premium plan with no credit card required. This gives you full access to all features so you can experience the full benefits before deciding to subscribe."
              },
              {
                question: "Can I cancel my subscription anytime?",
                answer: "Absolutely. You can cancel your subscription at any time through your account settings. If you cancel, you'll still have access to Premium features until the end of your current billing period."
              },
              {
                question: "How accurate is the nutrition tracking?",
                answer: "Our nutrition database contains over 1 million foods with detailed macro and micronutrient information. We regularly update our database and allow users to add custom foods and recipes for maximum accuracy."
              }
            ].map((faq, index) => (
              <RevealSection key={index} direction="up" className="bg-white rounded-xl shadow-md overflow-hidden">
                <motion.div
                  className="border-b border-gray-100 last:border-0"
                  initial={false}
                >
                  <motion.div 
                    className="px-6 py-4 flex justify-between items-center cursor-pointer"
                    onClick={() => {
                      // Toggle accordion logic would go here
                    }}
                  >
                    <h3 className="font-medium text-lg">{faq.question}</h3>
                    <svg className="w-5 h-5 text-purple-600 transform transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
                    </svg>
                  </motion.div>
                  <motion.div
                    className="px-6 py-4 text-gray-600"
                  >
                    {faq.answer}
                  </motion.div>
                </motion.div>
              </RevealSection>
            ))}
          </div>
        </div>
      </div>

      
      
      {/* Footer with staggered animation */}
      <footer className="bg-gray-900 text-white py-16 px-8 md:px-16">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
            <RevealSection direction="up" className="md:col-span-2">
              <h3 className="text-2xl font-bold mb-4">FitTrack</h3>
              <p className="text-gray-400 mb-6">The comprehensive fitness tracking platform that helps you achieve your health and fitness goals.</p>
              <div className="flex space-x-4">
                {['facebook', 'twitter', 'instagram', 'youtube'].map((social) => (
                  <motion.a 
                    key={social} 
                    href="#" 
                    className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center"
                    whileHover={{ backgroundColor: '#9333EA', y: -3 }}
                  >
                    <span className="sr-only">{social}</span>
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                      <path fillRule="evenodd" d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm0 18c-4.411 0-8-3.589-8-8s3.589-8 8-8 8 3.589 8 8-3.589 8-8 8z" clipRule="evenodd" />
                    </svg>
                  </motion.a>
                ))}
              </div>
            </RevealSection>
            
            <RevealSection direction="up">
              <h4 className="font-semibold text-lg mb-4">Company</h4>
              <ul className="space-y-2">
                {['About Us', 'Careers', 'Press', 'Blog'].map((item) => (
                  <li key={item}>
                    <motion.a href="#" className="text-gray-400 hover:text-white" whileHover={{ x: 3 }}>
                      {item}
                    </motion.a>
                  </li>
                ))}
              </ul>
            </RevealSection>
            
            <RevealSection direction="up">
              <h4 className="font-semibold text-lg mb-4">Support</h4>
              <ul className="space-y-2">
                {['Help Center', 'Contact Us', 'Privacy Policy', 'Terms of Service'].map((item) => (
                  <li key={item}>
                    <motion.a href="#" className="text-gray-400 hover:text-white" whileHover={{ x: 3 }}>
                      {item}
                    </motion.a>
                  </li>
                ))}
              </ul>
            </RevealSection>
          </div>
          
          <RevealSection direction="up">
            <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
              <p className="text-gray-500 text-sm">© 2025 FitTrack. All rights reserved.</p>
             
            </div>
          </RevealSection>
          
        </div>
        
      </footer>

      
      
      {/* Video modal */}
      <AnimatePresence>
        {showVideo && (
          <motion.div 
            className="fixed inset-0 bg-black bg-opacity-75 z-50 flex items-center justify-center p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowVideo(false)}
          >
            <motion.div 
              className="bg-white rounded-xl p-1 w-full max-w-3xl aspect-video"
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.8 }}
              onClick={e => e.stopPropagation()}
            >
              <div className="w-full h-full rounded-lg overflow-hidden">
                <video
                  className="w-full h-full object-cover"
                  controls
                  autoPlay
                >
                  <source src="/videos/video.mp4" type="video/mp4" />
                  Your browser does not support the video tag.
                </video>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Homepage;

