import React, { useState, useEffect } from "react";
import axios from "axios";

import {
  PlusCircle,
  Save,
  Activity,
  Droplets,
  Flame,
  Heart,
  Scale,
  Ruler,
  Clock,
  ChevronUp,
} from "lucide-react";

const useActivityData = () => {
  const [recentActivities, setRecentActivities] = useState([]);
  const [weeklyMinutes, setWeeklyMinutes] = useState(Array(7).fill(0));

  useEffect(() => {
    const userId = localStorage.getItem("userId");
    const token = localStorage.getItem("authToken");
    const config = { headers: { Authorization: `Bearer ${token}` } };

    axios
      .get(`http://localhost:5000/api/activity/recent/${userId}`, config)
      .then((res) => setRecentActivities(res.data))
      .catch((err) => console.error("Recent activities error:", err));

    axios
      .get(`http://localhost:5000/api/activity/weekly-log/${userId}`, config)
      .then((res) => {
        const minutes = Array(7).fill(0);
        res.data.forEach((entry) => {
          const date = new Date(entry.created_at);
          let day = (date.getDay() + 6) % 7; // shift to Mon-Sun
          minutes[day] += entry.duration;
        });
        setWeeklyMinutes(minutes);
      })
      .catch((err) => console.error("Weekly log error:", err));
  }, []);

  return { recentActivities, weeklyMinutes };
};





const Logging = () => {
  // State for form inputs
  const [formData, setFormData] = useState({
    steps: "",
    water: "",
    calories: "",
    heartRate: "",
    weight: "",
    height: "",
    age: "",
    activityType: "",
    activityDuration: "",
    sleepHours: "",
  });

  // State for animation effects
  const [showSuccess, setShowSuccess] = useState(false);
  const [scrollY, setScrollY] = useState(0);
  const [activeSection, setActiveSection] = useState(null);
  const { recentActivities, weeklyMinutes } = useActivityData();

  // Handle scroll for parallax effect
  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Handle input changes
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const logDailyMetrics = async () => {
    const token = localStorage.getItem("authToken");
    const userId = localStorage.getItem("userId");

    const data = {
      user_id: Number(userId),
      activity_id: 1,
      steps: Number(formData.steps) || 0,
      calories_burned: Number(formData.calories) || 0,
      average_heart_rate: Number(formData.heartRate) || 0,
      water_intake_ml: (Number(formData.water) || 0) * 1000,
    };

    try {
      await axios.post("http://localhost:5000/api/activity/user-action", data, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 3000);
    } catch (err) {
      console.error("Error logging metrics:", err);
    }
  };

  // Modify your handleSubmit function to call logDailyMetrics
  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log("Submitted data:", formData);

    try {
      await logDailyMetrics(); // Call your API function
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 3000);
    } catch (err) {
      console.error("Error submitting form:", err);
    }
  };

  // Scroll to top function
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // Set active section to trigger animations
  const setActive = (section) => {
    setActiveSection(section);
    setTimeout(() => setActiveSection(null), 1000);
  };

  // Get progress for visual meter based on input value
  const getProgress = (value, max) => {
    if (!value) return 0;
    return Math.min((parseInt(value) / max) * 100, 100);
  };

  const updateUserStats = async () => {
    try {
      const token = localStorage.getItem("authToken");
      const res = await axios.post(
        "http://localhost:5000/api/users/updateUserStats",
        {
          height: formData.height,
          weight: formData.weight,
        },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      console.log(res.data);
      setActive("stats");
    } catch (err) {
      console.error(err);
    }
  };

  const logActivity = async () => {
    const token = localStorage.getItem("authToken");
    const userId = localStorage.getItem("userId");

    const data = {
      activity: formData.activityType,
      duration: Number(formData.activityDuration) || 0,
    };

    try {
      await axios.post(
        `http://localhost:5000/api/activity/log/${userId}`,
        data,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );
      setActive("activity");
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 3000);
    } catch (err) {
      console.error("Error logging activity:", err);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-50 to-blue-50">
      {/* Hero Banner with Parallax Effect */}
      <div
        className="relative h-32 bg-indigo-600 overflow-hidden"
        style={{
          backgroundPosition: `center ${scrollY * 0.5}px`,
        }}
      >
        <div className="absolute inset-0 bg-white bg-opacity-70"></div>
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center px-4">
            <h1 className="text-4xl md:text-5xl font-bold text-black mb-2">
              Track Your Journey
            </h1>
            <p className="text-xl text-black">
              Log your progress and watch yourself transform
            </p>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-indigo-50 to-transparent"></div>
      </div>

      {/* Main Content */}
      <div className="w-full px-4 py-8">
        {showSuccess && (
          <div className="fixed top-6 left-0 right-0 mx-auto max-w-md z-50">
            <div className="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 rounded-lg shadow-lg animate-bounce">
              Data logged successfully! Keep up the great work! 🎉
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="max-w-6xl mx-auto">
          {/* Daily Metrics Section */}
          <div className="relative bg-white p-6 rounded-xl shadow-lg mb-12 border border-indigo-100 overflow-hidden transform transition-all duration-300 hover:shadow-xl">
            <div
              className={`absolute inset-0 bg-green-500 bg-opacity-10 transform scale-0 transition-transform duration-500 ${activeSection === "daily" ? "scale-100 rounded-xl" : ""}`}
            ></div>

            <h2 className="text-2xl font-bold mb-6 text-gray-800 flex items-center">
              <Activity className="mr-3 text-green-500" size={24} />
              Daily Metrics
              <button
                type="button"
                // onClick={() => setActive("daily")}
                onClick={logDailyMetrics}
                className="ml-auto text-indigo-500 hover:text-indigo-700"
              >
                <PlusCircle size={20} />
              </button>
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {/* Steps */}
              <div className="bg-white rounded-xl border border-green-100 shadow-sm overflow-hidden transition-all duration-300 hover:shadow-md hover:border-green-300">
                <div className="p-4">
                  <div className="flex items-center mb-2">
                    <Activity className="mr-2 text-green-500" size={20} />
                    <label
                      htmlFor="steps"
                      className="text-sm font-medium text-gray-700"
                    >
                      Steps
                    </label>
                  </div>
                  <input
                    type="number"
                    id="steps"
                    name="steps"
                    value={formData.steps}
                    onChange={handleChange}
                    placeholder="Enter steps"
                    className="block w-full border-0 focus:ring-0 focus:outline-none text-2xl font-bold text-gray-800 bg-transparent"
                  />
                  <div className="h-2 bg-gray-100 rounded-full mt-2 overflow-hidden">
                    <div
                      className="h-full bg-green-500 rounded-full transition-all duration-500"
                      style={{
                        width: `${getProgress(formData.steps, 10000)}%`,
                      }}
                    ></div>
                  </div>
                  <div className="text-xs text-gray-500 mt-1">
                    Daily goal: 10,000
                  </div>
                </div>
                <div className="bg-green-50 p-2 text-center text-sm font-medium text-green-700">
                  {formData.steps
                    ? `${getProgress(formData.steps, 10000).toFixed(0)}% of goal`
                    : "Enter your steps"}
                </div>
              </div>

              {/* Water */}
              <div className="bg-white rounded-xl border border-blue-100 shadow-sm overflow-hidden transition-all duration-300 hover:shadow-md hover:border-blue-300">
                <div className="p-4">
                  <div className="flex items-center mb-2">
                    <Droplets className="mr-2 text-blue-500" size={20} />
                    <label
                      htmlFor="water"
                      className="text-sm font-medium text-gray-700"
                    >
                      Water (Liters)
                    </label>
                  </div>
                  <input
                    type="number"
                    step="0.1"
                    id="water"
                    name="water"
                    value={formData.water}
                    onChange={handleChange}
                    placeholder="Enter water intake"
                    className="block w-full border-0 focus:ring-0 focus:outline-none text-2xl font-bold text-gray-800 bg-transparent"
                  />
                  <div className="relative h-8 mt-2">
                    <div className="absolute bottom-0 left-0 right-0 bg-blue-100 rounded-lg h-8">
                      <div
                        className="absolute bottom-0 left-0 bg-blue-400 rounded-lg transition-all duration-500"
                        style={{
                          width: "100%",
                          height: `${getProgress(formData.water, 3)}%`,
                          maxHeight: "100%",
                        }}
                      ></div>
                    </div>
                  </div>
                  <div className="text-xs text-gray-500 mt-1">
                    Daily goal: 3L
                  </div>
                </div>
                <div className="bg-blue-50 p-2 text-center text-sm font-medium text-blue-700">
                  {formData.water
                    ? `${getProgress(formData.water, 3).toFixed(0)}% hydrated`
                    : "Track your hydration"}
                </div>
              </div>

              {/* Calories */}
              <div className="bg-white rounded-xl border border-pink-100 shadow-sm overflow-hidden transition-all duration-300 hover:shadow-md hover:border-pink-300">
                <div className="p-4">
                  <div className="flex items-center mb-2">
                    <Flame className="mr-2 text-pink-500" size={20} />
                    <label
                      htmlFor="calories"
                      className="text-sm font-medium text-gray-700"
                    >
                      Calories
                    </label>
                  </div>
                  <input
                    type="number"
                    id="calories"
                    name="calories"
                    value={formData.calories}
                    onChange={handleChange}
                    placeholder="Enter calories"
                    className="block w-full border-0 focus:ring-0 focus:outline-none text-2xl font-bold text-gray-800 bg-transparent"
                  />
                  <div className="flex items-center mt-2">
                    <div className="w-full bg-gray-100 rounded-full h-2.5">
                      <div
                        className="bg-pink-500 h-2.5 rounded-full transition-all duration-500"
                        style={{
                          width: `${getProgress(formData.calories, 2000)}%`,
                        }}
                      ></div>
                    </div>
                  </div>
                  <div className="text-xs text-gray-500 mt-1">
                    Daily target: 2,000
                  </div>
                </div>
                <div className="bg-pink-50 p-2 text-center text-sm font-medium text-pink-700">
                  {formData.calories
                    ? `${formData.calories} / 2000 calories`
                    : "Track your intake"}
                </div>
              </div>

              {/* Heart Rate */}
              <div className="bg-white rounded-xl border border-purple-100 shadow-sm overflow-hidden transition-all duration-300 hover:shadow-md hover:border-purple-300">
                <div className="p-4">
                  <div className="flex items-center mb-2">
                    <Heart className="mr-2 text-purple-500" size={20} />
                    <label
                      htmlFor="heartRate"
                      className="text-sm font-medium text-gray-700"
                    >
                      Heart Rate (BPM)
                    </label>
                  </div>
                  <input
                    type="number"
                    id="heartRate"
                    name="heartRate"
                    value={formData.heartRate}
                    onChange={handleChange}
                    placeholder="Enter heart rate"
                    className="block w-full border-0 focus:ring-0 focus:outline-none text-2xl font-bold text-gray-800 bg-transparent"
                  />

                  <div className="mt-2 relative h-8">
                    <svg className="w-full h-8" viewBox="0 0 100 20">
                      <path
                        d="M0,10 Q10,0 20,10 T40,10 T60,10 T80,10 T100,10"
                        fill="none"
                        stroke="#E9D5FF"
                        strokeWidth="2"
                      />

                      {formData.heartRate && (
                        <path
                          d="M0,10 Q10,0 20,10 T40,10 T60,10 T80,10 T100,10"
                          fill="none"
                          stroke="#A855F7"
                          strokeWidth="2"
                          strokeDasharray="100"
                          strokeDashoffset={
                            100 - getProgress(formData.heartRate, 200)
                          }
                        />
                      )}
                    </svg>
                  </div>
                  <div className="text-xs text-gray-500 mt-1">
                    Resting: 60-100 BPM
                  </div>
                </div>
                <div className="bg-purple-50 p-2 text-center text-sm font-medium text-purple-700">
                  {formData.heartRate
                    ? `${formData.heartRate} BPM`
                    : "Check your pulse"}
                </div>
              </div>
            </div>
          </div>

          {/* Personal Stats */}
          <div className="relative bg-white p-6 rounded-xl shadow-lg mb-12 border border-indigo-100 overflow-hidden transform transition-all duration-300 hover:shadow-xl">
            <div
              className={`absolute inset-0 bg-indigo-500 bg-opacity-10 transform scale-0 transition-transform duration-500 ${activeSection === "stats" ? "scale-100 rounded-xl" : ""}`}
            ></div>

            <h2 className="text-2xl font-bold mb-6 text-gray-800 flex items-center">
              <Scale className="mr-3 text-indigo-500" size={24} />
              Personal Stats
              <button
                type="button"
                onClick={() => updateUserStats()}
                className="ml-auto text-indigo-500 hover:text-indigo-700"
              >
                <PlusCircle size={20} />
              </button>
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Weight */}
              <div className="bg-indigo-50 rounded-xl p-4 shadow-sm hover:shadow-md transition-all duration-300">
                <div className="flex items-center mb-3">
                  <Scale className="text-indigo-500 mr-2" size={24} />
                  <h3 className="text-lg font-medium text-indigo-700">
                    Weight
                  </h3>
                </div>
                <div className="flex items-end space-x-2">
                  <input
                    type="number"
                    step="0.1"
                    id="weight"
                    name="weight"
                    value={formData.weight}
                    onChange={handleChange}
                    placeholder="0"
                    className="text-3xl font-bold bg-transparent border-b-2 border-indigo-200 focus:border-indigo-500 focus:outline-none w-24 text-indigo-900"
                  />
                  <span className="text-xl text-indigo-700 mb-1">kg</span>
                </div>
                <div className="mt-4">
                  <div className="h-1 w-full bg-indigo-200 rounded-full">
                    <div
                      className="h-1 rounded-full bg-indigo-500 transition-all duration-500"
                      style={{
                        width: `${formData.weight ? Math.min((formData.weight / 150) * 100, 100) : 0}%`,
                      }}
                    ></div>
                  </div>
                </div>
              </div>

              {/* Height */}
              <div className="bg-blue-50 rounded-xl p-4 shadow-sm hover:shadow-md transition-all duration-300">
                <div className="flex items-center mb-3">
                  <Ruler className="text-blue-500 mr-2" size={24} />
                  <h3 className="text-lg font-medium text-blue-700">Height</h3>
                </div>
                <div className="flex items-end space-x-2">
                  <input
                    type="number"
                    id="height"
                    name="height"
                    value={formData.height}
                    onChange={handleChange}
                    placeholder="0"
                    className="text-3xl font-bold bg-transparent border-b-2 border-blue-200 focus:border-blue-500 focus:outline-none w-24 text-blue-900"
                  />
                  <span className="text-xl text-blue-700 mb-1">cm</span>
                </div>
                <div className="relative h-16 mt-2">
                  <div className="absolute bottom-0 left-0 right-0 flex items-end space-x-1">
                    {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
                      <div
                        key={i}
                        className="flex-1 bg-blue-200 rounded-t transition-all duration-300"
                        style={{
                          height: `${i * 12.5}%`,
                          opacity:
                            formData.height && (formData.height / 200) * 8 >= i
                              ? 1
                              : 0.3,
                        }}
                      ></div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Sleep */}
              <div className="bg-orange-50 rounded-xl p-4 shadow-sm hover:shadow-md transition-all duration-300">
                <div className="flex items-center mb-3">
                  <Clock className="text-orange-500 mr-2" size={24} />
                  <h3 className="text-lg font-medium text-orange-700">Sleep</h3>
                </div>
                <div className="flex items-end space-x-2">
                  <input
                    type="number"
                    step="0.5"
                    id="sleepHours"
                    name="sleepHours"
                    value={formData.sleepHours}
                    onChange={handleChange}
                    placeholder="0"
                    className="text-3xl font-bold bg-transparent border-b-2 border-orange-200 focus:border-orange-500 focus:outline-none w-24 text-orange-900"
                  />
                  <span className="text-xl text-orange-700 mb-1">hours</span>
                </div>
                <div className="flex items-center justify-between mt-4">
                  <div className="text-sm text-orange-700">Less</div>
                  <div className="w-full mx-2">
                    <div className="h-2 w-full bg-orange-200 rounded-full">
                      <div
                        className={`h-2 rounded-full transition-all duration-500 ${
                          formData.sleepHours < 6
                            ? "bg-red-500"
                            : formData.sleepHours > 9
                              ? "bg-green-500"
                              : "bg-orange-500"
                        }`}
                        style={{
                          width: `${formData.sleepHours ? Math.min((formData.sleepHours / 12) * 100, 100) : 0}%`,
                        }}
                      ></div>
                    </div>
                  </div>
                  <div className="text-sm text-orange-700">More</div>
                </div>
              </div>
            </div>
          </div>

          {/* Activity Logging */}
          <div className="relative bg-white p-6 rounded-xl shadow-lg mb-12 border border-indigo-100 overflow-hidden transform transition-all duration-300 hover:shadow-xl">
            <div
              className={`absolute inset-0 bg-green-500 bg-opacity-10 transform scale-0 transition-transform duration-500 ${activeSection === "activity" ? "scale-100 rounded-xl" : ""}`}
            ></div>

            <h2 className="text-2xl font-bold mb-6 text-gray-800 flex items-center">
              <Activity className="mr-3 text-green-500" size={24} />
              Activity Log
              <button
                type="button"
                onClick={() => logActivity()}
                className="ml-auto text-green-500 hover:text-green-700"
              >
                <PlusCircle size={20} />
              </button>
            </h2>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label
                      htmlFor="activityType"
                      className="block text-sm font-medium text-gray-700 mb-2"
                    >
                      Activity Type
                    </label>
                    <select
                      id="activityType"
                      name="activityType"
                      value={formData.activityType}
                      onChange={handleChange}
                      className="block w-full rounded-lg border-gray-300 bg-gray-50 shadow-sm focus:border-green-500 focus:ring focus:ring-green-200 focus:ring-opacity-50 h-12 transition-all duration-200"
                    >
                      <option value="">Select an activity</option>
                      <option value="Cardio">Cardio</option>
                      <option value="Stretching">Stretching</option>
                      <option value="Treadmill">Treadmill</option>
                      <option value="Strength">Strength Training</option>
                      <option value="Running">Running</option>
                      <option value="Cycling">Cycling</option>
                      <option value="Swimming">Swimming</option>
                      <option value="Yoga">Yoga</option>
                    </select>
                  </div>
                  <div>
                    <label
                      htmlFor="activityDuration"
                      className="block text-sm font-medium text-gray-700 mb-2"
                    >
                      Duration (minutes)
                    </label>
                    <input
                      type="number"
                      id="activityDuration"
                      name="activityDuration"
                      value={formData.activityDuration}
                      onChange={handleChange}
                      placeholder="Duration in minutes"
                      className="block w-full rounded-lg border-gray-300 bg-gray-50 shadow-sm focus:border-green-500 focus:ring focus:ring-green-200 focus:ring-opacity-50 h-12 transition-all duration-200"
                    />
                  </div>
                </div>

                <div className="bg-green-50 rounded-lg p-4 shadow-inner">
                  <h3 className="text-lg font-medium text-green-700 mb-2">
                    Recent Activities
                  </h3>
                  <div className="space-y-2">
                    {recentActivities.map((a, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between bg-white p-3 rounded-md shadow-sm"
                      >
                        <span>
                          {a.activity} - {a.duration} min
                        </span>
                        <span className="text-sm text-gray-500">
                          {a.created_at
                            ? new Date(a.created_at).toLocaleDateString()
                            : "Unknown"}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="bg-green-50 rounded-xl p-4 shadow-sm">
                <h3 className="text-lg font-medium text-green-700 mb-4">
                  Weekly Activity Goal
                </h3>
                <div className="relative pt-1">
                  <div className="flex mb-2 items-center justify-between">
                    <div>
                      <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-green-600 bg-green-200">
                        Progress
                      </span>
                    </div>
                    <div className="text-right">
                      <span className="text-xs font-semibold inline-block text-green-600">
                        {formData.activityDuration
                          ? `${Math.min(((parseInt(formData.activityDuration) || 0) / 150) * 100, 100).toFixed(0)}%`
                          : "0%"}
                      </span>
                    </div>
                  </div>
                  <div className="overflow-hidden h-4 mb-4 text-xs flex rounded-full bg-green-200">
                    <div
                      style={{
                        width: formData.activityDuration
                          ? `${Math.min(((parseInt(formData.activityDuration) || 0) / 150) * 100, 100)}%`
                          : "0%",
                      }}
                      className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-green-500 transition-all duration-500"
                    ></div>
                  </div>
                  <p className="text-sm text-green-700">
                    Goal: 150 minutes per week
                  </p>
                </div>

                <div className="mt-6">
                  <div className="grid grid-cols-7 gap-1 text-center">
                    {["M", "T", "W", "T", "F", "S", "S"].map((day, i) => (
                       <div key={i} className="text-xs font-medium text-green-700">
                       {day}
                     </div>
                    ))}
                    {weeklyMinutes.map((mins, i) => (
                      <div
                        key={i + 7}
                        className="h-6 rounded-sm"
                        style={{
                          backgroundColor: mins > 0 ? "#34D399" : "#D1FAE5",
                          opacity: mins > 0 ? mins / 60 + 0.3 : 0.3,
                        }}
                      ></div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <div className="flex justify-end">
            <button
              type="submit"
              className="group relative flex items-center justify-center px-8 py-4 bg-indigo-500 text-white font-medium text-lg rounded-lg shadow-lg hover:bg-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-opacity-50 transform transition hover:scale-105 overflow-hidden"
            >
              <span className="absolute right-full group-hover:right-4 transition-all duration-500 opacity-0 group-hover:opacity-100">
                <Save size={20} />
              </span>
              <span className="group-hover:mr-6 transition-all duration-300">
                Save Your Progress
              </span>
            </button>
          </div>
        </form>
      </div>

      {/* Back to top button */}
      <button
        className="fixed bottom-6 right-6 bg-indigo-500 text-white p-3 rounded-full shadow-lg hover:bg-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-400 focus:ring-opacity-50 transition-all duration-300 hover:scale-110"
        onClick={scrollToTop}
      >
        <ChevronUp size={20} />
      </button>
    </div>
  );
};

export default Logging;
