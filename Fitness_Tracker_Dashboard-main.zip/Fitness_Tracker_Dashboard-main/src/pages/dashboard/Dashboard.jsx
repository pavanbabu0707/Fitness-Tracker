import React, { useState, useEffect } from "react";
import axios from "axios";
import {
  Bell,
  ChevronDown,
  BarChart2,
  ChevronRight,
  MoreHorizontal,
} from "lucide-react";

// Enhanced mock data for the dashboard
const userData = {
  location: "Arlington, Texas",
  monthlyProgress: 90,
};

// Helper components
const ProgressCircle = ({ percentage, size = "lg", children }) => {
  const radius = size === "lg" ? 48 : 24;
  const strokeWidth = size === "lg" ? 8 : 6;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (percentage / 100) * circumference;

  return (
    <div className="relative">
      <svg
        width={radius * 2 + strokeWidth}
        height={radius * 2 + strokeWidth}
        className="transform -rotate-90"
      >
        <circle
          cx={radius + strokeWidth / 2}
          cy={radius + strokeWidth / 2}
          r={radius}
          fill="transparent"
          stroke="#E5E7EB"
          strokeWidth={strokeWidth}
        />
        <circle
          cx={radius + strokeWidth / 2}
          cy={radius + strokeWidth / 2}
          r={radius}
          fill="transparent"
          stroke={percentage > 60 ? "#10B981" : "#F59E0B"}
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        {children}
      </div>
    </div>
  );
};

const MultiColorProgressBar = ({ values }) => {
  return (
    <div className="w-full h-2 rounded-full flex overflow-hidden">
      {values.map((item, index) => (
        <div
          key={index}
          className="h-full"
          style={{ backgroundColor: item.color, width: `${item.percentage}%` }}
        />
      ))}
    </div>
  );
};

const StarRating = ({ rating }) => {
  return (
    <div className="flex">
      {[...Array(5)].map((_, i) => (
        <div
          key={i}
          className={`text-lg ${i < rating ? "text-yellow-400" : "text-gray-300"}`}
        >
          ★
        </div>
      ))}
    </div>
  );
};

// Main dashboard component
const FitnessDashboard = () => {
  const [weeklyView, setWeeklyView] = useState("activity");
  const [selectedDay, setSelectedDay] = useState(4); // Friday selected by default (index 4)
  const [dailyProgress, setDailyProgress] = useState(null);

  const [dietMenuData, setDietMenuData] = useState({ breakfast: [] });
  const [scheduledActivities, setScheduledActivities] = useState([]);

  const [totalHours, setTotalHours] = useState(0);
  const [activeWorkout, setActiveWorkout] = useState(null);
  const [activeMeal, setActiveMeal] = useState(null);

  useEffect(() => {
    const fetchWorkoutHours = async () => {
      try {
        const token = localStorage.getItem("authToken");
        const userId = localStorage.getItem("userId");

        const res = await axios.get(
          `http://localhost:5000/api/activity/workout-hours/${userId}`,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );

        setTotalHours(Number(res.data.totalHours));
      } catch (err) {
        console.error(err);
      }
    };

    fetchWorkoutHours();
  }, []);

  useEffect(() => {
    const fetchScheduledActivities = async () => {
      try {
        const token = localStorage.getItem("authToken");
        const userId = localStorage.getItem("userId");

        const res = await axios.get(
          `http://localhost:5000/api/schedule/activities/${userId}`,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );

        setScheduledActivities(res.data);
      } catch (err) {
        console.error(err);
      }
    };

    fetchScheduledActivities();
  }, []);

  useEffect(() => {
    const fetchBreakfast = async () => {
      try {
        const token = localStorage.getItem("authToken");
        const userId = localStorage.getItem("userId");

        const res = await axios.get(
          `http://localhost:5000/api/diet/breakfast/${userId}`,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
        setDietMenuData({ breakfast: res.data.breakfast });
      } catch (err) {
        console.error(err);
      }
    };

    fetchBreakfast();
  }, []);

  // Create a state for user stats that can be updated from API
  const [userStats, setUserStats] = useState({
    weight: { value: null, unit: "kg" },
    height: { value: null, unit: "ft" },
    age: { value: null, unit: "yrs" },
  });

  const [userName, setUserName] = useState("Loading..."); // Default loading state
  useEffect(() => {
    const fetchDashboardData = async () => {
      const token = localStorage.getItem("authToken");
      const userId = localStorage.getItem("userId");

      try {
        // Fetch user stats
        const userRes = await axios.get(
          "http://localhost:5000/api/users/current",
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );

        setUserStats({
          weight: {
            value: parseFloat(userRes.data.weight_kg).toFixed(1),
            unit: "kg",
          },
          height: {
            value: parseFloat(userRes.data.height_cm * 0.0328084).toFixed(1),
            unit: "ft",
          },
          age: {
            value: calculateAge(new Date(userRes.data.date_of_birth)),
            unit: "yrs",
          },
        });

        setUserName(`${userRes.data.first_name} ${userRes.data.last_name}`);

        // Fetch daily progress
        const progressRes = await axios.get(
          `http://localhost:5000/api/activity/latest/${userId}`,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );

        const d = progressRes.data;

        setDailyProgress({
          steps: {
            current: d.steps,
            goal: 5000,
            percentage: Math.round((d.steps / 5000) * 100),
          },
          water: {
            current: parseFloat(d.waterIntakeLiters),
            goal: 3,
            percentage: Math.round((d.waterIntakeLiters / 3) * 100),
            unit: "Liters",
          },
          calories: {
            current: d.caloriesBurned,
            goal: 2000,
            percentage: Math.round((d.caloriesBurned / 2000) * 100),
            status: "Under",
          },
          heartRate: { current: d.averageHeartRate, unit: "bpm" },
        });
      } catch (error) {
        console.error("getLatestActivity error:", error);

        console.error("Dashboard data fetch error:", error);
        setUserName("Error Loading Name");
        setUserStats({
          weight: { value: "N/A", unit: "kg" },
          height: { value: "N/A", unit: "ft" },
          age: { value: "N/A", unit: "yrs" },
        });
      }
    };

    fetchDashboardData();
  }, []);

  // Fetch user stats from backend
  useEffect(() => {
    const fetchUserStats = async () => {
      try {
        // Get token from localStorage or wherever you're storing it
        const token = localStorage.getItem("authToken"); // Adjust this based on how you store the token

        const response = await axios.get(
          "http://localhost:5000/api/users/current",
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );

        // Update user stats from backend response
        setUserStats({
          weight: {
            value: parseFloat(response.data.weight_kg).toFixed(1),
            unit: "kg",
          },
          height: {
            value: parseFloat(response.data.height_cm * 0.0328084).toFixed(1),
            unit: "ft",
          },
          age: {
            value: calculateAge(new Date(response.data.date_of_birth)),
            unit: "yrs",
          },
        });

        // Set full name
        setUserName(`${response.data.first_name} ${response.data.last_name}`);
      } catch (error) {
        console.error("Error fetching user stats:", error);
        setUserName("Error Loading Name");
        // Optionally, set a default or error state for stats
        setUserStats({
          weight: { value: "N/A", unit: "kg" },
          height: { value: "N/A", unit: "m" },
          age: { value: "N/A", unit: "yrs" },
        });
      }
    };

    fetchUserStats();
  }, []);

  // Helper function to calculate age
  const calculateAge = (birthDate) => {
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDifference = today.getMonth() - birthDate.getMonth();

    if (
      monthDifference < 0 ||
      (monthDifference === 0 && today.getDate() < birthDate.getDate())
    ) {
      age--;
    }

    return age;
  };

  const [weeklyActivity, setWeeklyActivity] = useState([]);

  useEffect(() => {
    const fetchWeeklyActivity = async () => {
      try {
        const token = localStorage.getItem("authToken");
        const userId = localStorage.getItem("userId");

        const response = await axios.get(
          `http://localhost:5000/api/activity/weekly/${userId}`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );

        setWeeklyActivity(response.data);
      } catch (error) {
        console.error("Error fetching weekly activity:", error);
        setWeeklyActivity([]); // fallback
      }
    };

    fetchWeeklyActivity();
  }, []);

  const [workoutBreakdown, setWorkoutBreakdown] = useState([]);

  useEffect(() => {
    const fetchWorkoutBreakdown = async () => {
      try {
        const token = localStorage.getItem("authToken");
        const userId = localStorage.getItem("userId");

        const response = await axios.get(
          `http://localhost:5000/api/activity/workout/${userId}`,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );

        setWorkoutBreakdown(response.data); // this line only
      } catch (error) {
        console.error("Error fetching workout breakdown:", error);
      }
    };

    fetchWorkoutBreakdown();
  }, []);

  const [goals, setGoals] = useState([]);

  useEffect(() => {
    const fetchGoals = async () => {
      try {
        const token = localStorage.getItem("authToken");
        const userId = 4;

        const response = await axios.get(
          `http://localhost:5000/api/activity/goals/${userId}`,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );

        setGoals(response.data);
      } catch (error) {
        console.error("Error fetching goals:", error);
      }
    };

    fetchGoals();
  }, []);

  const [recommendedWorkouts, setRecommendedWorkouts] = useState([]);

  useEffect(() => {
    const fetchRecommendedWorkouts = async () => {
      try {
        const token = localStorage.getItem("authToken");
        const userId = localStorage.getItem("userId");

        const response = await axios.get(
          `http://localhost:5000/api/activity/recommended/${userId}`,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );

        setRecommendedWorkouts(response.data);
      } catch (error) {
        console.error("Error fetching recommended workouts:", error);
      }
    };

    fetchRecommendedWorkouts();
  }, []);

  return (
    <div className="flex justify-center ">
      <div className="bg-gray-50 min-h-screen font-sans">
        {/* Header */}
        <header className="bg-white p-4 flex justify-between items-center border-b">
          <div>
            <h1 className="text-xl font-bold flex items-center">
              Welcome Back <span className="ml-1">🎉</span>
            </h1>
          </div>
          <div className="flex items-center space-x-4">
            <button className="p-2 rounded-full hover:bg-gray-100">
              <Bell size={20} />
            </button>
            <div className="flex items-center">
              <img
                src="/images/profile.png"
                alt="Profile"
                className="w-8 h-8 rounded-full"
              />
              <div className="ml-2 text-sm">
                <div className="font-medium">{userName}</div>
                <div className="text-gray-500 text-xs flex items-center">
                  <span className="mr-1">📍</span>
                  {userData.location}
                </div>
              </div>
            </div>
          </div>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 p-4">
          {/* Main Content - Left 3 columns */}
          <div className="col-span-1 lg:col-span-3 space-y-4">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {/* Steps Card */}
              <div className="bg-emerald-500 text-white rounded-lg p-4 flex flex-col">
                <div className="flex items-center mb-2">
                  <span className="mr-1">👣</span>
                  <span>Steps</span>
                </div>
                <div className="text-2xl font-bold mb-1">
                  {dailyProgress?.steps.current || 0}
                  <span className="text-sm font-normal ml-1">Steps</span>
                </div>
                <div className="text-xs mt-auto">50% of your goals</div>
              </div>

              {/* Water Card */}
              <div className="bg-yellow-400 text-white rounded-lg p-4 relative overflow-hidden">
                <div className="flex items-center mb-2">
                  <span className="mr-1">💧</span>
                  <span>Water</span>
                </div>
                <div className="flex items-center justify-center h-16">
                  <ProgressCircle percentage={48} size="sm">
                    <div className="text-center">
                      <div className="text-xl font-bold">
                        {dailyProgress?.water.current || 0}
                      </div>
                      <div className="text-xs">Liters</div>
                    </div>
                  </ProgressCircle>
                </div>
              </div>

              {/* Calories Card */}
              <div className="bg-pink-500 text-white rounded-lg p-4">
                <div className="flex items-center mb-2">
                  <span className="mr-1">🔥</span>
                  <span>Calories</span>
                </div>
                <div className="flex flex-col items-center">
                  <div className="w-16 h-16 relative">
                    <div className="absolute inset-0">
                      <svg viewBox="0 0 100 100">
                        <path
                          d="M 50,50 m 0,-45 a 45,45 0 1 1 0,90 a 45,45 0 1 1 0,-90"
                          stroke="#FFC0CB"
                          strokeWidth="10"
                          fillOpacity="0"
                        />
                        <path
                          d="M 50,50 m 0,-45 a 45,45 0 1 1 0,90 a 45,45 0 1 1 0,-90"
                          stroke="#FFFFFF"
                          strokeWidth="10"
                          fillOpacity="0"
                          strokeDasharray="283"
                          strokeDashoffset="170"
                        />
                      </svg>
                    </div>
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <div className="font-bold">
                        {dailyProgress?.calories.current || 0}
                      </div>
                      <div className="text-xs">Under</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Heart Rate Card */}
              <div className="bg-purple-500 text-white rounded-lg p-4">
                <div className="flex items-center mb-2">
                  <span className="mr-1">❤️</span>
                  <span>Heart Rate</span>
                </div>
                <div className="h-12 mb-2">
                  <svg viewBox="0 0 100 20" className="w-full h-full">
                    <path
                      d="M 0,10 Q 5,0 10,10 Q 15,20 20,10 Q 25,0 30,10 Q 35,20 40,10 Q 45,0 50,10 Q 55,20 60,10 Q 65,0 70,10 Q 75,20 80,10 Q 85,0 90,10 Q 95,20 100,10"
                      fill="none"
                      stroke="white"
                      strokeWidth="1.5"
                    />
                  </svg>
                </div>
                <div className="text-2xl font-bold">
                  {dailyProgress?.heartRate.current || 0}{" "}
                  <span className="text-sm font-normal">bpm</span>
                </div>
              </div>
            </div>

            {/* Weekly Activity and Progress */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-amber-50 p-4 rounded-lg shadow-sm">
              {/* Activity Chart - Enhanced with more data */}
              <div className="bg-white rounded-lg p-4 shadow-sm">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="font-bold">Activity</h2>
                  <div className="flex items-center text-sm text-gray-500">
                    <span>Weekly</span>
                    <ChevronDown size={16} />
                  </div>
                </div>
                <div className="flex h-48 items-end space-x-2">
                  {weeklyActivity.map((day, index) => {
                    const isHighest =
                      day.value ===
                      Math.max(...weeklyActivity.map((d) => d.value));
                    const isSelected = index === selectedDay;
                    return (
                      <div
                        key={index}
                        className="flex-1 flex flex-col items-center cursor-pointer"
                        onClick={() => setSelectedDay(index)}
                      >
                        {isSelected && (
                          <div className="bg-blue-800 text-white text-xs px-1 rounded-sm text-center mb-1 w-12">
                            {day.value}%
                          </div>
                        )}
                        <div
                          className={`w-3 rounded-t-md ${isSelected ? "bg-blue-800" : "bg-blue-300"}`}
                          style={{ height: `${day.value * 1.5}px` }}
                        />
                        <div
                          className={`mt-1 text-sm ${isSelected ? "font-bold" : "text-gray-500"}`}
                        >
                          {day.day}
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Activity details for selected day */}
                <div className="mt-4 pt-4 border-t">
                  <div className="flex justify-between">
                    <div className="text-sm text-gray-600">
                      <span className="font-medium">
                        {weeklyActivity[selectedDay]?.day}
                      </span>{" "}
                      Activity
                    </div>
                    <div className="text-sm font-medium text-blue-600">
                      {weeklyActivity[selectedDay]?.value}% of goal
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4 mt-2">
                    <div className="text-sm">
                      <div className="text-gray-500">Calories</div>
                      <div className="font-bold">
                        {weeklyActivity[selectedDay]?.calories} cal
                      </div>
                    </div>
                    <div className="text-sm">
                      <div className="text-gray-500">Steps</div>
                      <div className="font-bold">
                        {weeklyActivity[selectedDay]?.steps}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Progress Breakdown - Larger progress chart */}
              <div className="bg-white rounded-lg p-4 shadow-sm">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="font-bold">Progress</h2>
                  <div className="flex items-center text-sm text-gray-500">
                    <span>Weekly</span>
                    <ChevronDown size={16} />
                  </div>
                </div>
                <div className="flex justify-center mb-4">
                  {/* Increased size of progress chart */}
                  <div className="w-48 h-48 relative">
                    <svg viewBox="0 0 100 100" className="w-full h-full">
                      <circle
                        cx="50"
                        cy="50"
                        r="45"
                        fill="transparent"
                        stroke="#E5E7EB"
                        strokeWidth="8"
                      />
                      <circle
                        cx="50"
                        cy="50"
                        r="45"
                        fill="transparent"
                        stroke="#3B82F6"
                        strokeWidth="8"
                        strokeDasharray="282.7"
                        strokeDashoffset="198"
                        strokeLinecap="round"
                      />
                      <circle
                        cx="50"
                        cy="50"
                        r="45"
                        fill="transparent"
                        stroke="#F59E0B"
                        strokeWidth="8"
                        strokeDasharray="282.7"
                        strokeDashoffset="169.6"
                        strokeLinecap="round"
                        transform="rotate(120 50 50)"
                      />
                      <circle
                        cx="50"
                        cy="50"
                        r="45"
                        fill="transparent"
                        stroke="#EC4899"
                        strokeWidth="8"
                        strokeDasharray="282.7"
                        strokeDashoffset="198"
                        strokeLinecap="round"
                        transform="rotate(240 50 50)"
                      />
                      <text
                        x="50"
                        y="48"
                        textAnchor="middle"
                        dominantBaseline="middle"
                        className="text-3xl font-bold"
                        fill="#4B5563"
                      >
                        {totalHours}
                      </text>
                      <text
                        x="50"
                        y="60"
                        textAnchor="middle"
                        dominantBaseline="middle"
                        className="text-sm"
                        fill="#6B7280"
                      >
                        hours
                      </text>
                    </svg>
                  </div>
                </div>

                <div className="space-y-2">
                  {workoutBreakdown.map((workout, index) => (
                    <div key={index} className="flex items-center">
                      <div
                        className="w-3 h-3 rounded-full mr-2"
                        style={{ backgroundColor: workout.color }}
                      ></div>
                      <div className="flex-1">{workout.name}</div>
                      <div className="text-gray-500">{workout.hours} hrs</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Recommended Workouts and Diet Menu */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Recommended Workouts */}
              <div className="bg-white rounded-lg p-4 shadow-sm">
                <h2 className="font-bold mb-4">Recomended workout for you</h2>
                <div className="grid grid-cols-2 gap-4">
                  {recommendedWorkouts.map((workout) => (
                    <div
                      key={workout.workout_id}
                      className="border rounded-lg overflow-hidden cursor-pointer"
                      onClick={() => setActiveWorkout(workout)}
                    >
                      <img
                        src={workout.image}
                        alt={workout.name}
                        className="w-full h-32 object-cover"
                      />
                      <div className="p-3">
                        <h3 className="font-medium">{workout.name}</h3>
                        <p className="text-sm text-gray-500 truncate">
                          {workout.description}
                        </p>
                      </div>
                    </div>
                  ))}

                  {activeWorkout && (
                    <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50">
                      <div className="bg-white p-6 rounded-lg w-full max-w-md relative">
                        <button
                          onClick={() => setActiveWorkout(null)}
                          className="absolute top-2 right-2 text-gray-500 hover:text-gray-700"
                        >
                          ✕
                        </button>
                        <img
                          src={activeWorkout.image}
                          alt={activeWorkout.name}
                          className="w-full h-48 object-cover rounded"
                        />
                        <h2 className="text-xl font-bold mt-4">
                          {activeWorkout.name}
                        </h2>
                        <p className="mt-2 text-gray-700">
                          {activeWorkout.description}
                        </p>
                        <div className="mt-3 text-sm text-gray-500">
                          Difficulty: {activeWorkout.difficulty} <br />
                          ❤️ {activeWorkout.likes} · 💬 {activeWorkout.comments}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Featured Diet Menu - Scrollable */}
              <div className="bg-white rounded-lg p-4 shadow-sm">
                <h2 className="font-bold mb-4">Featured Diet Menu</h2>
                <div>
                  <h3 className="text-purple-500 mb-2">Breakfast</h3>
                  <div className="max-h-60 overflow-y-auto pr-2">
  <div className="space-y-4">
    {dietMenuData.breakfast.map((item, index) => (
      <div
        key={index}
        className="flex border-b pb-4 last:border-0 cursor-pointer"
        onClick={() => setActiveMeal(item)}
      >
        <img
          src={item.image}
          alt={item.name}
          className="w-12 h-12 object-cover rounded-lg mr-3"
        />
        <div className="flex-1">
          <div className="font-medium">{item.name}</div>
          <MultiColorProgressBar
            values={[
              {
                color: "#8B5CF6",
                percentage: Math.floor(
                  (item.protein / (item.protein + item.fat + item.carbs)) * 100
                ),
              },
              {
                color: "#F59E0B",
                percentage: Math.floor(
                  (item.fat / (item.protein + item.fat + item.carbs)) * 100
                ),
              },
              {
                color: "#EF4444",
                percentage: Math.floor(
                  (item.carbs / (item.protein + item.fat + item.carbs)) * 100
                ),
              },
            ]}
          />
          <div className="text-xs text-gray-500 mt-1">{item.calories} cal</div>
        </div>
        <div className="text-xs text-gray-400 whitespace-nowrap">{item.time}</div>
      </div>
    ))}
  </div>
</div>
{activeMeal && (
  <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50">
    <div className="bg-white p-6 rounded-lg w-full max-w-md relative">
      <button
        onClick={() => setActiveMeal(null)}
        className="absolute top-2 right-2 text-gray-500 hover:text-gray-700"
      >
        ✕
      </button>
      <img
        src={activeMeal.image}
        alt={activeMeal.name}
        className="w-full h-48 object-cover rounded"
      />
      <h2 className="text-xl font-bold mt-4">{activeMeal.name}</h2>
      <p className="mt-2 text-gray-700 text-sm">{activeMeal.description || 'No description available.'}</p>
      <div className="mt-3 text-sm text-gray-600">
        Protein: {activeMeal.protein}g · Fat: {activeMeal.fat}g · Carbs: {activeMeal.carbs}g  
        <br />
        Calories: {activeMeal.calories} cal  
        <br />
        Time: {activeMeal.time}
      </div>
    </div>
  </div>
)}

                </div>
              </div>
            </div>
          </div>

          {/* Sidebar - Right column */}
          <div className="col-span-1 space-y-4">
            {/* Personal Stats */}
            <div className="bg-white rounded-lg p-4 shadow-sm flex justify-between">
              <div className="text-center">
                <div className="text-xl font-bold">
                  {userStats.weight.value}
                </div>
                <div className="text-gray-500 text-xs">
                  {userStats.weight.unit}
                </div>
                <div className="text-xs">Weight</div>
              </div>
              <div className="text-center">
                <div className="text-xl font-bold">
                  {userStats.height.value}
                </div>
                <div className="text-gray-500 text-xs">
                  {userStats.height.unit}
                </div>
                <div className="text-xs">Height</div>
              </div>
              <div className="text-center">
                <div className="text-xl font-bold">{userStats.age.value}</div>
                <div className="text-gray-500 text-xs">
                  {userStats.age.unit}
                </div>
                <div className="text-xs">Age</div>
              </div>
            </div>

            {goals.map((goal, index) => (
              <div key={index} className="flex items-center">
                <div className="bg-gray-100 p-2 rounded-lg mr-3">
                  {index === 0 && <span className="text-lg">🏃</span>}
                  {index === 1 && <span className="text-lg">😴</span>}
                  {index === 2 && <span className="text-lg">🔥</span>}
                </div>
                <div className="flex-1">
                  <div className="flex justify-between">
                    <div className="font-medium">{goal.name}</div>
                    <div className="text-sm font-medium text-green-500">
                      {goal.progress}%
                    </div>
                  </div>
                  <div className="text-xs text-gray-500 mb-1">
                    {goal.target}
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-1.5">
                    <div
                      className="bg-green-500 h-1.5 rounded-full"
                      style={{ width: `${goal.progress}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            ))}

            {/* Monthly Progress */}
            <div className="bg-white rounded-lg p-4 shadow-sm">
              <h2 className="font-bold mb-4">Monthly Progress</h2>
              <div className="flex justify-center mb-2">
                <div className="relative">
                  <svg className="w-32 h-32">
                    <circle
                      cx="64"
                      cy="64"
                      r="56"
                      fill="transparent"
                      stroke="#E5E7EB"
                      strokeWidth="8"
                    />
                    <circle
                      cx="64"
                      cy="64"
                      r="56"
                      fill="transparent"
                      stroke="#F97316"
                      strokeWidth="8"
                      strokeDasharray="351.68"
                      strokeDashoffset="70.336"
                      strokeLinecap="round"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-2xl font-bold text-gray-800">80%</div>
                  </div>
                </div>
              </div>
              <div className="text-center text-sm text-gray-600">
                You have achieved 80% of your goal this month
              </div>
            </div>

            {/* Scheduled Activities - Scrollable */}
            <div className="bg-white rounded-lg p-4 shadow-sm">
              <h2 className="font-bold mb-4">Scheduled</h2>
              <div className="max-h-56 overflow-y-auto pr-2">
                <div className="space-y-3">
                  {scheduledActivities.map((activity, index) => (
                    <div
                      key={index}
                      className="flex items-center border-b pb-3 last:border-0"
                    >
                      <div className="bg-gray-100 p-2 rounded-lg mr-3">
                        <img
                          src={activity.image}
                          alt={activity.name}
                          className="w-8 h-8 rounded-full object-cover"
                        />
                      </div>
                      <div className="flex-1">
                        <div className="font-medium">
                          {activity.type} - {activity.name}
                        </div>
                        <div className="text-xs text-gray-500">
                          {activity.category}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm">{activity.date}</div>
                        <button className="text-gray-400">
                          <MoreHorizontal size={16} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FitnessDashboard;
