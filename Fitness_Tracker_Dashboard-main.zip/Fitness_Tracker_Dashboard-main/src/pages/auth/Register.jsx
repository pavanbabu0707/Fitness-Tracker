import React, { useState } from "react";
import Particles from "react-tsparticles";
import { loadSlim } from "tsparticles-slim";

const Register = ({ onRegisterSuccess }) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
    first_name: "",
    last_name: "",
    gender: "",
    date_of_birth: "",
    activity_level: "",
    goal: "",
    height_cm: "",
    weight_kg: "",
  });
  const [message, setMessage] = useState({ text: "", type: "" });

  const particlesInit = async (engine) => {
    await loadSlim(engine);
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleNext = (e) => {
    e.preventDefault();
    setStep(2);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch("http://localhost:5000/api/users/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });
      const data = await res.json();
      if (res.ok) {
        setMessage({ text: "Registration successful!", type: "success" });
        onRegisterSuccess();
      } else {
        setMessage({ text: data.message || "Registration failed", type: "error" });
      }
    } catch {
      setMessage({ text: "Server error", type: "error" });
    }
  };

  return (
    <div className="min-h-screen relative flex items-center justify-center p-4 overflow-hidden">
      <Particles
        id="tsparticles"
        init={particlesInit}
        className="absolute inset-0 z-0"
        options={{
          background: { color: { value: "#0d1117" } },
          fpsLimit: 60,
          interactivity: {
            events: {
              onClick: { enable: true, mode: "push" },
              onHover: { enable: true, mode: "repulse" },
              resize: true,
            },
            modes: { push: { quantity: 4 }, repulse: { distance: 100, duration: 0.4 } },
          },
          particles: {
            color: { value: ["#9c27b0", "#673ab7", "#3f51b5", "#2196f3", "#00bcd4"] },
            links: { color: "#ffffff", distance: 150, enable: true, opacity: 0.3, width: 1 },
            collisions: { enable: true },
            move: { direction: "none", enable: true, outModes: { default: "bounce" }, speed: 1.2 },
            number: { density: { enable: true, area: 800 }, value: 80 },
            opacity: { value: 0.5 },
            shape: { type: "circle" },
            size: { value: { min: 1, max: 5 } },
          },
          detectRetina: true,
        }}
      />

      <div className="w-full max-w-md z-10">
        <div className="bg-white/10 backdrop-blur-md rounded-2xl shadow-2xl overflow-hidden border border-white/20">
          <div className="h-1.5 bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500"></div>
          <div className="p-8">
            <div className="text-center mb-6">
              <h2 className="text-3xl font-bold text-white">Create Account</h2>
              <p className="text-gray-300 mt-1">Step {step} of 2</p>
            </div>

            {message.text && (
              <div
                className={`mb-6 p-4 rounded-lg flex items-center ${
                  message.type === "success"
                    ? "bg-green-400/20 text-green-100 border border-green-400/30"
                    : "bg-red-400/20 text-red-100 border border-red-400/30"
                }`}
              >
                <span className="text-lg mr-2">{message.type === "success" ? "✓" : "✕"}</span>
                <span>{message.text}</span>
              </div>
            )}

            <form onSubmit={step === 1 ? handleNext : handleSubmit} className="space-y-4">
              {step === 1 ? (
                <>
                  <input name="first_name" placeholder="First Name" required onChange={handleChange} className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400" />
                  <input name="last_name" placeholder="Last Name" required onChange={handleChange} className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400" />
                  <input name="email" type="email" placeholder="Email" required onChange={handleChange} className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400" />
                  <input name="password" type="password" placeholder="Password" required onChange={handleChange} className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400" />
                  <input name="username" placeholder="Username" required onChange={handleChange} className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400" />
                  <button type="submit" className="w-full bg-gradient-to-r from-violet-600 to-indigo-600 text-white py-3 px-4 rounded-xl hover:from-violet-700 hover:to-indigo-700 transition duration-300 font-medium">Next</button>
                </>
              ) : (
                <>
                  <select name="gender" required onChange={handleChange} className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-black">
                    <option value="">Gender</option>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                  </select>
                  <input name="date_of_birth" type="date" required onChange={handleChange} className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white" />
                  <select name="activity_level" required onChange={handleChange} className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-black">
                    <option value="">Activity Level</option>
                    <option value="Sedentary">Sedentary</option>
                    <option value="Lightly Active">Lightly Active</option>
                    <option value="Moderately Active">Moderately Active</option>
                    <option value="Very Active">Very Active</option>
                  </select>
                  <select name="goal" required onChange={handleChange} className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-black">
                    <option value="">Goal</option>
                    <option value="Lose Weight">Lose Weight</option>
                    <option value="Maintain Weight">Maintain Weight</option>
                    <option value="Gain Weight">Gain Weight</option>
                  </select>
                  <input name="height_cm" type="number" placeholder="Height (cm)" required onChange={handleChange} className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-black placeholder-gray-400" />
                  <input name="weight_kg" type="number" placeholder="Weight (kg)" required onChange={handleChange} className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-black placeholder-gray-400" />
                  <button type="submit" className="w-full bg-gradient-to-r from-violet-600 to-indigo-600 text-white py-3 px-4 rounded-xl hover:from-violet-700 hover:to-indigo-700 transition duration-300 font-medium">Submit</button>
                </>
              )}
            </form>

            <div className="mt-6 text-center">
              <p className="text-gray-300">
                Already have an account?{" "}
                <button type="button" onClick={onRegisterSuccess} className="text-indigo-300 font-medium hover:text-indigo-200">
                  Log In
                </button>
              </p>
            </div>
          </div>
        </div>

        <div className="mt-8 text-center text-white/60 text-sm">
          © {new Date().getFullYear()} Company Name. All rights reserved.
        </div>
      </div>
    </div>
  );
};

export default Register;
