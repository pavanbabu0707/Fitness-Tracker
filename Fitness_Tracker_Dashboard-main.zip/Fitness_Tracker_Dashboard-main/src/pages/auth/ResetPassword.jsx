import { useState } from 'react';
import Particles from 'react-tsparticles';
import { loadSlim } from 'tsparticles-slim';

const ResetPassword = ({ onBackToLogin }) => {
  const [step, setStep] = useState(1);
  const [email, setEmail] = useState('');
  const [dob, setDob] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [message, setMessage] = useState('');

  const particlesInit = async (engine) => {
    await loadSlim(engine);
  };

  const verifyUser = async (e) => {
    e.preventDefault();
    const res = await fetch('http://localhost:5000/api/users/verify-reset', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, date_of_birth: dob }),
    });
    const data = await res.json();
    if (res.ok) {
      setStep(2);
      setMessage('');
    } else {
      setMessage(data.message || 'Verification failed');
    }
  };

  const resetPassword = async (e) => {
    e.preventDefault();
    const res = await fetch('http://localhost:5000/api/users/reset-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, new_password: newPassword }),
    });
    const data = await res.json();
    setMessage(data.message);
    if (res.ok) setTimeout(onBackToLogin, 2000);
  };

  return (
    <div className="min-h-screen relative flex items-center justify-center p-4 overflow-hidden">
      <Particles
        id="tsparticles"
        init={particlesInit}
        className="absolute inset-0 z-0"
        options={{
          background: { color: { value: "#0d1117" } },
          fpsLimit: 60,
          interactivity: {
            events: {
              onClick: { enable: true, mode: "push" },
              onHover: { enable: true, mode: "repulse" },
              resize: true,
            },
            modes: { push: { quantity: 4 }, repulse: { distance: 100, duration: 0.4 } },
          },
          particles: {
            color: { value: ["#9c27b0", "#673ab7", "#3f51b5", "#2196f3", "#00bcd4"] },
            links: { color: "#ffffff", distance: 150, enable: true, opacity: 0.3, width: 1 },
            collisions: { enable: true },
            move: { direction: "none", enable: true, outModes: { default: "bounce" }, speed: 1.2 },
            number: { density: { enable: true, area: 800 }, value: 80 },
            opacity: { value: 0.5 },
            shape: { type: "circle" },
            size: { value: { min: 1, max: 5 } },
          },
          detectRetina: true,
        }}
      />

      <div className="w-full max-w-md z-10">
        <div className="bg-white/10 backdrop-blur-md rounded-2xl shadow-2xl overflow-hidden border border-white/20">
          <div className="h-1.5 bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500"></div>
          <div className="p-8">
            <div className="text-center mb-6">
              <h2 className="text-3xl font-bold text-white">Reset Password</h2>
              <p className="text-gray-300">{step === 1 ? "Verify your identity" : "Set new password"}</p>
            </div>

            {message && (
              <div className="mb-6 p-4 rounded-lg bg-red-400/20 text-red-100 border border-red-400/30 text-sm">
                {message}
              </div>
            )}

            {step === 1 ? (
              <form onSubmit={verifyUser} className="space-y-4">
                <input
                  type="email"
                  placeholder="Your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400"
                />
                <input
                  type="date"
                  value={dob}
                  onChange={(e) => setDob(e.target.value)}
                  required
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white"
                />
                <button
                  type="submit"
                  className="w-full bg-gradient-to-r from-violet-600 to-indigo-600 text-white py-3 px-4 rounded-xl hover:from-violet-700 hover:to-indigo-700 transition duration-300 font-medium"
                >
                  Verify
                </button>
              </form>
            ) : (
              <form onSubmit={resetPassword} className="space-y-4">
                <input
                  type="password"
                  placeholder="New Password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  required
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400"
                />
                <button
                  type="submit"
                  className="w-full bg-gradient-to-r from-violet-600 to-indigo-600 text-white py-3 px-4 rounded-xl hover:from-violet-700 hover:to-indigo-700 transition duration-300 font-medium"
                >
                  Set New Password
                </button>
              </form>
            )}

            <div className="mt-6 text-center">
              <button onClick={onBackToLogin} className="text-indigo-300 hover:text-indigo-200 font-medium">
                Back to Login
              </button>
            </div>
          </div>
        </div>

        <div className="mt-8 text-center text-white/60 text-sm">
          © {new Date().getFullYear()} Company Name. All rights reserved.
        </div>
      </div>
    </div>
  );
};

export default ResetPassword;
