import React, { useState } from "react";

const Contact = () => {
  const [formState, setFormState] = useState({
    submitting: false,
    succeeded: false,
    errors: {}
  });
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    message: ""
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFormState({ ...formState, submitting: true });
    
    // Simulate form submission
    try {
      // Replace with actual form submission logic
      await new Promise(resolve => setTimeout(resolve, 1000));
      setFormState({
        submitting: false,
        succeeded: true,
        errors: {}
      });
      setFormData({
        firstName: "",
        lastName: "",
        email: "",
        phone: "",
        message: ""
      });
    } catch (error) {
      setFormState({
        submitting: false,
        succeeded: false,
        errors: { message: "Something went wrong. Please try again." }
      });
    }
  };

  const conferenceLocation = {
    address: "701 S Nedderman Dr",
    city: "Arlington",
    state: "TX",
    zipCode: "76019",
    country: "USA",
    mapUrl:
      "https://maps.google.com/maps?q=University+of+Texas+at+Arlington&t=&z=13&ie=UTF8&iwloc=&output=embed",
  };

  const SocialIcon = ({ icon }) => (
    <a 
      href="#" 
      className="w-8 h-8 flex items-center justify-center rounded-full bg-purple-100 text-purple-700 hover:bg-purple-700 hover:text-white transition-all duration-300"
    >
      <i className={`fab fa-${icon}`}></i>
    </a>
  );

  const ContactInfo = ({ icon, title, content }) => (
    <div className="flex items-start space-x-3 mb-4">
      <div className="mt-1 w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center text-purple-700">
        <i className={`fas fa-${icon} text-lg`}></i>
      </div>
      <div>
        <h4 className="font-medium text-gray-800">{title}</h4>
        <p className="text-white">{content}</p>
      </div>
    </div>
  );

  return (
    <div className="w-full min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Get in Touch</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            We'd love to hear from you. Please fill out the form below or use our contact information.
          </p>
        </div>

        <div className="bg-white shadow-xl rounded-2xl overflow-hidden grid grid-cols-1 lg:grid-cols-3">
          {/* Contact Information */}
          <div className="bg-gradient-to-br from-purple-600 to-purple-800 p-8 text-white">
            <h2 className="text-2xl font-bold mb-6  ">Contact Information</h2>
            
            <div className="space-y-6 mb-12 text-white">
              <ContactInfo 
                icon="map-marker-alt" 
                title="Address" 
                content={`${conferenceLocation.address}, ${conferenceLocation.city}, ${conferenceLocation.state} ${conferenceLocation.zipCode}`} 
              />
              <ContactInfo 
                icon="envelope" 
                title="Email" 
                content="contact@conferenceexample.com" 
              />
              <ContactInfo 
                icon="phone-alt" 
                title="Phone" 
                content="+1 (555) 123-4567" 
              />
              <ContactInfo 
                icon="clock" 
                title="Working Hours" 
                content="Monday - Friday, 9:00 AM - 5:00 PM" 
              />
            </div>

          
          </div>

          {/* Contact Form */}
          <div className="col-span-2 p-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor="firstName">
                    First Name *
                  </label>
                  <input
                    id="firstName"
                    type="text"
                    name="firstName"
                    value={formData.firstName}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-purple-500 focus:border-transparent transition"
                    placeholder="Enter your first name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor="lastName">
                    Last Name *
                  </label>
                  <input
                    id="lastName"
                    type="text"
                    name="lastName"
                    value={formData.lastName}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-purple-500 focus:border-transparent transition"
                    placeholder="Enter your last name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor="email">
                    Email Address *
                  </label>
                  <input
                    id="email"
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-purple-500 focus:border-transparent transition"
                    placeholder="your.email@example.com"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor="phone">
                    Phone Number
                  </label>
                  <input
                    id="phone"
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-purple-500 focus:border-transparent transition"
                    placeholder="(123) 456-7890"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor="message">
                  Your Message *
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  rows="5"
                  required
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-purple-500 focus:border-transparent transition"
                  placeholder="How can we help you?"
                ></textarea>
              </div>


              <button
                type="submit"
                disabled={formState.submitting}
                className="w-full md:w-auto px-8 py-3 bg-purple-600 hover:bg-purple-700 text-white font-medium rounded-lg transition duration-300 flex items-center justify-center disabled:opacity-70"
              >
                {formState.submitting ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Sending...
                  </>
                ) : (
                  "Send Message"
                )}
              </button>

              {formState.succeeded && (
                <div className="mt-4 p-4 bg-green-50 text-green-700 rounded-lg">
                  Thank you for your message! We'll get back to you soon.
                </div>
              )}
              
              {formState.errors.message && (
                <div className="mt-4 p-4 bg-red-50 text-red-700 rounded-lg">
                  {formState.errors.message}
                </div>
              )}
            </form>
          </div>
        </div>

        {/* Map Section */}
        <div className="mt-12 bg-white shadow-lg rounded-2xl overflow-hidden">
          <div className="p-6 bg-purple-50">
            <h2 className="text-2xl font-bold text-purple-800">Conference Location</h2>
            <p className="text-gray-600 mt-2">Join us at the University of Texas at Arlington</p>
          </div>
          <div className="h-96">
            <iframe
              src={conferenceLocation.mapUrl}
              className="w-full h-full border-0"
              allowFullScreen=""
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Conference Location Map"
            ></iframe>
          </div>
        </div>

       
      </div>
    </div>
  );
};

export default Contact;