import { useState, useEffect } from "react";
import { Outlet, Navigate, useLocation } from "react-router-dom";
import "./App.css";
import Navbar from "./components/Navbar";
import Login from "./pages/auth/Login";
import Register from "./pages/auth/Register";
import ResetPassword from "./pages/auth/ResetPassword"; // import it
import "@fortawesome/fontawesome-free/css/all.min.css";

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(() => {
    return localStorage.getItem("isLoggedIn") === "true";
  });

  const location = useLocation();
  const [showRegister, setShowRegister] = useState(false);
  const [showReset, setShowReset] = useState(false);

  const handleLogin = () => {
    localStorage.setItem("isLoggedIn", "true");
    setIsLoggedIn(true);
  };

  return (
    <>
      {isLoggedIn ? (
        <>
          <Navbar />
          <Outlet />
        </>
      ) : showReset ? (
        <ResetPassword onBackToLogin={() => setShowReset(false)} />
      ) : showRegister ? (
        <Register onRegisterSuccess={() => setShowRegister(false)} />
      ) : (
        <Login
          onLoginSuccess={handleLogin}
          onSwitchToRegister={() => setShowRegister(true)}
          onForgotPassword={() => setShowReset(true)}
        />
      )}
    </>
  );
}

export default App;
