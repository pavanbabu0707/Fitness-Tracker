// db.js (Make sure this path is correct in your project)
const mysql = require('mysql2');

// const pool = mysql.createPool({
//   host: 'beaencnmgvdxor6wy4b7-mysql.services.clever-cloud.com',
//   user: 'uetjoahpizvhnlsq',
//   password: 'et3aq2D4LkDXbEH8O9Rf',  
//   database: 'beaencnmgvdxor6wy4b7',
//   port: 3306,
// });

const pool = mysql.createPool({
  host: '127.0.0.1',
  user: 'root',
  password: 'password',  
  database: 'fitnessdashboard',
  port: 3306,
});

module.exports = pool;
