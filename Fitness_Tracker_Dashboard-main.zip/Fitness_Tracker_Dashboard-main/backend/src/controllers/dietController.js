const db = require('../config/db');

const getBreakfast = (req, res) => {
  const userId = req.params.userId;
  console.log("Fetching breakfast for user:", userId); // Debug log

  const query = `
    SELECT name, image, calories, protein, fat, carbs, description,
    TIME_FORMAT(time, '%h:%i %p') as time 
    FROM diet_menu 
    WHERE user_id = ? AND meal_type = 'Breakfast'
  `;

  db.query(query, [userId], (err, results) => {
    if (err) {
      console.error("SQL error:", err); // Debug log
      return res.status(500).json({ error: "Database error" });
    }
    res.json({ breakfast: results });
  });
};


module.exports = { getBreakfast };
