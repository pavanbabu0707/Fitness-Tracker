const db = require('../config/db');

const getScheduledActivities = (req, res) => {
  const userId = req.params.userId;

  const query = `
    SELECT 
      exercise_name AS name,
      scheduled_date AS date,
      scheduled_time,
      duration_minutes 
    FROM scheduled_exercises 
    WHERE user_id = ?
  `;

  db.query(query, [userId], (err, results) => {
    if (err) return res.status(500).json({ error: "Database error" });

    const activities = results.map((item) => ({
      type: "Training",
      name: item.name,
      category: "Fitness",
      date: formatDate(item.date),
      image: getImage(item.name),
    }));

    res.json(activities);
  });
};

const formatDate = (dateStr) => {
  const d = new Date(dateStr);
  return d.toLocaleDateString("en-GB", {
    day: "2-digit",
    month: "short",
  }).replace(" ", " ");
};

const getImage = (name) => {
  const lower = name.toLowerCase();
  if (lower.includes("yoga")) return "/images/yoga.jpg";
  if (lower.includes("swimming")) return "/images/swimming.jpeg";
  if (lower.includes("hiit")) return "/images/HIIT.png";
  if (lower.includes("meditation")) return "/images/meditation.jpg";
  return "/images/default.jpg";
};

module.exports = { getScheduledActivities };
