const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const db = require('../config/db');  // Your database connection

// Login Controller - Issue JWT token
const login = (req, res) => {
  const { email, password } = req.body;

  // Query the database to find the user by username
  db.query('SELECT * FROM users WHERE email = ?', [email], (err, results) => {
    if (err) return res.status(500).json({ message: 'Server error' });

    if (results.length === 0) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    const user = results[0];
    // Compare the provided password with the hashed password in the database
    bcrypt.compare(password, user.password_hash, (err, isMatch) => {
      if (err) return res.status(500).json({ message: 'Server error' });
      if (!isMatch) return res.status(401).json({ message: 'Invalid credentials' });

      // Create a JWT token with the user_id
      const token = jwt.sign({ userId: user.user_id }, 'your_jwt_secret', { expiresIn: '1h' });
      res.json({ message: 'Login successful', token });
    });
  });
};

// Get Current User Controller - For logged-in user
const getCurrentUser = (req, res) => {
  const userId = req.user.userId; // The user ID is stored in the request by authenticateToken

  // Query the database to get the logged-in user's details
  db.query('SELECT * FROM users WHERE user_id = ?', [userId], (err, results) => {
    if (err) return res.status(500).json({ message: 'Server error' });

    if (results.length === 0) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json(results[0]);  // Return the user details
  });
};

const logoutUser = (req, res) => {
  // If using JWT without blacklist, just respond success
  res.status(200).json({ message: 'Logged out successfully' });
};

const register = async (req, res) => {
  const {
    username, email, password, first_name, last_name,
    gender, date_of_birth, activity_level, goal, height_cm, weight_kg
  } = req.body;

  db.query('SELECT * FROM users WHERE email = ?', [email], async (err, results) => {
    if (err) return res.status(500).json({ message: 'Server error' });
    if (results.length > 0) return res.status(400).json({ message: 'User already exists' });

    const password_hash = await bcrypt.hash(password, 10);

    const insertQuery = `
      INSERT INTO users (username, email, password_hash, first_name, last_name, gender, date_of_birth, activity_level, goal, height_cm, weight_kg)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    const values = [username, email, password_hash, first_name, last_name, gender, date_of_birth, activity_level, goal, height_cm, weight_kg];

    db.query(insertQuery, values, (err, result) => {
      if (err) return res.status(500).json({ message: 'Registration failed' });
      res.status(201).json({ message: 'User registered successfully' });
    });
  });
};

const verifyReset = (req, res) => {
  const { email, date_of_birth } = req.body;
  db.query(
    'SELECT * FROM users WHERE email = ? AND date_of_birth = ?',
    [email, date_of_birth],
    (err, results) => {
      if (err) return res.status(500).json({ message: 'Server error' });
      if (results.length === 0) return res.status(404).json({ message: 'User not found' });
      res.json({ message: 'Verified' });
    }
  );
};

const resetPassword = async (req, res) => {
  const { email, new_password } = req.body;
  const hash = await bcrypt.hash(new_password, 10);
  db.query(
    'UPDATE users SET password_hash = ? WHERE email = ?',
    [hash, email],
    (err, result) => {
      if (err) return res.status(500).json({ message: 'Failed to update password' });
      res.json({ message: 'Password updated successfully' });
    }
  );
};

const updateUserStats = (req, res) => {
  const userId = req.user.userId;
  const { height, weight } = req.body;

  const sql = `
    UPDATE users
    SET height_cm = ?, weight_kg = ?
    WHERE user_id = ?
  `;

  db.query(sql, [height, weight, userId], (err) => {
    if (err) return res.status(500).json({ message: 'Update failed' });
    res.status(200).json({ message: 'User stats updated' });
  });
};





module.exports = { login, getCurrentUser , logoutUser, register, resetPassword, verifyReset, updateUserStats};
