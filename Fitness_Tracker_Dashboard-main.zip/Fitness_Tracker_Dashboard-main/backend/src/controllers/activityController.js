const db = require('../config/db');

const insertUserAction = async (req, res) => {
  const { user_id, activity_id, steps, calories_burned, average_heart_rate, water_intake_ml } = req.body;

  const query = `
    INSERT INTO user_actions 
    (user_id, activity_id, action_date, steps, calories_burned, average_heart_rate, water_intake_ml) 
    VALUES (?, ?, CURRENT_DATE, ?, ?, ?, ?)
  `;

  try {
    await db.promise().query(query, [user_id, activity_id, steps, calories_burned, average_heart_rate, water_intake_ml]);
    res.status(201).json({ message: "User action inserted" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

const getLatestActivity = async (req, res) => {
  try {
    const { userId } = req.params;

    const query = `SELECT steps, water_intake_ml, calories_burned, average_heart_rate 
                   FROM user_actions 
                   WHERE user_id = ? 
                   ORDER BY action_date DESC 
                   LIMIT 1`;

    const [results] = await db.promise().query(query, [userId]);

    if (results.length === 0) {
      return res.status(404).json({ message: 'No activity data found' });
    }

    const row = results[0];
    const ML_TO_LITERS = 1000;

    res.json({
      steps: row.steps,
      waterIntakeLiters: (row.water_intake_ml / ML_TO_LITERS).toFixed(2),
      caloriesBurned: row.calories_burned,
      averageHeartRate: row.average_heart_rate,
    });
  } catch (error) {
    res.status(500).json({ message: 'Internal Server Error', error: error.message });
  }
};

const getAllActivities = async (req, res) => {
  try {
    const { userId } = req.params;
    const [results] = await db.promise().query(
      `SELECT * FROM user_actions WHERE user_id = ? ORDER BY action_date DESC`, [userId]
    );
    res.json(results);
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
};

const getWeeklyActivity = async (req, res) => {
  try {
    const { userId } = req.params;
    const [results] = await db.promise().query(
      `SELECT day, value, calories, steps 
       FROM weekly_activity 
       WHERE user_id = ? 
       ORDER BY activity_id`, [userId]
    );
    res.json(results);
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
};

const getWorkoutBreakdown = async (req, res) => {
  try {
    const { userId } = req.params;
    const [results] = await db.promise().query(
      `SELECT name, hours, color FROM workout_types WHERE user_id = ?`, [userId]
    );
    res.json(results);
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
};

const getGoals = async (req, res) => {
  try {
    const { userId } = req.params;
    const [results] = await db.promise().query(
      `SELECT name, target, progress FROM goals WHERE user_id = ?`, [userId]
    );
    res.json(results);
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
};

const getRecommendedWorkouts = async (req, res) => {
  try {
    const { userId } = req.params;
    const [results] = await db.promise().query(
      `SELECT name, description, difficulty, likes, comments, image 
       FROM recommended_workouts WHERE user_id = ?`, [userId]
    );
    res.json(results);
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
};

const getTotalWorkoutHours = async (req, res) => {
  try {
    const { userId } = req.params;

    const query = `SELECT SUM(hours) AS total_hours 
                   FROM workout_types 
                   WHERE user_id = ?`;

    const [results] = await db.promise().query(query, [userId]);

    const totalHours = results[0].total_hours || 0;

    res.json({ 
      success: true,
      totalHours: totalHours
    });
  } catch (error) {
    res.status(500).json({ 
      success: false,
      message: 'Internal Server Error', 
      error: error.message 
    });
  }
};

const logActivity = async (req, res) => {
  try {
    const { activity, duration } = req.body;
    const hours = duration / 60;
    const { userId } = req.params;
    const color = '#' + Math.floor(Math.random() * 16777215).toString(16).padStart(6, '0');

    const sql = `INSERT INTO workout_types (user_id, name, hours, color, created_at) 
                 VALUES (?, ?, ?, ?, NOW())`;
    await db.promise().query(sql, [userId, activity, hours, color]);
    res.status(200).json({ message: 'Activity logged successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

const getRecentActivities = async (req, res) => {
  try {
    const { userId } = req.params;

    const sql = `
      SELECT name, hours, created_at 
      FROM workout_types 
      WHERE user_id = ? 
      ORDER BY created_at DESC 
      LIMIT 3
    `;

    const [results] = await db.promise().query(sql, [userId]);
    const formatted = results.map(r => ({
      activity: r.name,
      duration: Math.round(r.hours * 60),
      created_at: r.created_at
    }));
    res.json(formatted);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

const getWeeklyLog = async (req, res) => {
  try {
    const { userId } = req.params;

    const sql = `
      SELECT name AS activity, hours, created_at 
      FROM workout_types 
      WHERE user_id = ? AND YEARWEEK(created_at, 1) = YEARWEEK(CURDATE(), 1)
    `;

    const [results] = await db.promise().query(sql, [userId]);
    const formatted = results.map(r => ({
      activity: r.activity,
      duration: Math.round(r.hours * 60),
      created_at: r.created_at
    }));

    res.json(formatted);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = { 
  getLatestActivity, 
  getAllActivities, 
  getWeeklyActivity, 
  getWorkoutBreakdown, 
  getGoals, 
  getRecommendedWorkouts,
  getTotalWorkoutHours,
  insertUserAction,
  logActivity,
  getRecentActivities,
  getWeeklyLog
};
