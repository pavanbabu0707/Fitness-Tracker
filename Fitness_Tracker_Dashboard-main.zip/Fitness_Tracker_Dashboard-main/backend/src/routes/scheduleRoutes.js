const express = require('express');
const router = express.Router();
const { getScheduledActivities } = require('../controllers/scheduleController');
const { authenticateToken } = require('../middlewares/authMiddleware');

router.get('/activities/:userId', authenticateToken, getScheduledActivities);

module.exports = router;
