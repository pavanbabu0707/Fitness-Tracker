const express = require('express');
const router = express.Router();
const { login, getCurrentUser } = require('../controllers/userController');
const { authenticateToken } = require('../middlewares/authMiddleware');
const { logoutUser, register } = require('../controllers/userController');
const { verifyReset, resetPassword, updateUserStats } = require('../controllers/userController');


// Route for login (POST request)
router.post('/login', login);

// Route to get the currently logged-in user (GET request)
router.get('/current', authenticateToken, getCurrentUser);  // Protected route

router.post('/logout', authenticateToken, logoutUser);
router.post('/register', register);

router.post('/verify-reset', verifyReset);
router.post('/reset-password', resetPassword);

router.post('/updateUserStats', authenticateToken, updateUserStats);




module.exports = router;

