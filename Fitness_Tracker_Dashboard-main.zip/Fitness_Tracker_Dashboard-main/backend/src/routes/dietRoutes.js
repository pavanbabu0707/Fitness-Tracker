const express = require('express');
const router = express.Router();
const { getBreakfast } = require('../controllers/dietController');
const { authenticateToken } = require('../middlewares/authMiddleware');

router.get('/breakfast/:userId', authenticateToken, getBreakfast);

module.exports = router;
