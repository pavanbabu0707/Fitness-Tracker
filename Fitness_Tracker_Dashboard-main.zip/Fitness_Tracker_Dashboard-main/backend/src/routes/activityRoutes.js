const express = require('express');
const router = express.Router();
const { insertUserAction, getLatestActivity, getAllActivities, getWeeklyActivity, getWorkoutBreakdown, getGoals, getRecommendedWorkouts, getTotalWorkoutHours, logActivity, getRecentActivities, getWeeklyLog} = require('../controllers/activityController');
const { authenticateToken } = require('../middlewares/authMiddleware');

router.get('/latest/:userId', authenticateToken, getLatestActivity);
router.get('/user/:userId', authenticateToken, getAllActivities);
router.get('/weekly/:userId', authenticateToken, getWeeklyActivity);
router.get('/workout/:userId', authenticateToken, getWorkoutBreakdown);
router.get('/goals/:userId', authenticateToken, getGoals);
router.get('/recommended/:userId', authenticateToken, getRecommendedWorkouts);
router.get('/workout-hours/:userId', authenticateToken, getTotalWorkoutHours);
router.post('/user-action', authenticateToken, insertUserAction);
router.post('/log/:userId', authenticateToken, logActivity);
router.get('/recent/:userId', authenticateToken, getRecentActivities);
router.get('/weekly-log/:userId', authenticateToken, getWeeklyLog);



module.exports = router;
