const express = require('express');
const app = express();
const jwt = require('jsonwebtoken');
const cors = require('cors');
const bodyParser = require('body-parser');
const { authenticateToken } = require('./middlewares/authMiddleware');  // We'll create this next

// Middleware
app.use(cors());
app.use(bodyParser.json()); // for parsing application/json

// Import your routes
const userRoutes = require('./routes/userRoutes');
app.use('/api/users', userRoutes);

const activityRoutes = require('./routes/activityRoutes');
app.use('/api/activity', activityRoutes);

const dietRoutes = require('./routes/dietRoutes');
app.use('/api/diet', dietRoutes);

const scheduleRoutes = require('./routes/scheduleRoutes');
app.use('/api/schedule', scheduleRoutes);

const chatRoute = require('./routes/chatRoute.js');
app.use('/api/chat', chatRoute);





// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
